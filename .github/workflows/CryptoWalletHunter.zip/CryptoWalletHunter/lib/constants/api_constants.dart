class ApiConstants {
  // API Keys - Replace with your own or use environment variables
  static const String etherscanApiKey = String.fromEnvironment('ETHERSCAN_API_KEY', defaultValue: '');
  static const String blockchairApiKey = String.fromEnvironment('BLOCKCHAIR_API_KEY', defaultValue: '');
  
  // API Endpoints
  // SoChain API
  static const String sochainBaseUrl = 'https://sochain.com/api/v2';
  static String sochainAddressBalance(String network, String address) => 
      '$sochainBaseUrl/get_address_balance/$network/$address';
  
  // Blockchair API
  static const String blockchairBaseUrl = 'https://api.blockchair.com';
  static String blockchairBitcoinBalance(String address) => 
      '$blockchairBaseUrl/bitcoin/dashboards/address/$address${blockchairApiKey.isNotEmpty ? "?key=$blockchairApiKey" : ""}';
  static String blockchairEthereumBalance(String address) => 
      '$blockchairBaseUrl/ethereum/dashboards/address/$address${blockchairApiKey.isNotEmpty ? "?key=$blockchairApiKey" : ""}';
  static String blockchairDogecoinBalance(String address) => 
      '$blockchairBaseUrl/dogecoin/dashboards/address/$address${blockchairApiKey.isNotEmpty ? "?key=$blockchairApiKey" : ""}';
  static String blockchairLitecoinBalance(String address) => 
      '$blockchairBaseUrl/litecoin/dashboards/address/$address${blockchairApiKey.isNotEmpty ? "?key=$blockchairApiKey" : ""}';
  static String blockchairDashBalance(String address) => 
      '$blockchairBaseUrl/dash/dashboards/address/$address${blockchairApiKey.isNotEmpty ? "?key=$blockchairApiKey" : ""}';
  
  // Etherscan API
  static const String etherscanBaseUrl = 'https://api.etherscan.io/api';
  static String etherscanBalance(String address) => 
      '$etherscanBaseUrl?module=account&action=balance&address=$address&tag=latest&apikey=${etherscanApiKey.isNotEmpty ? etherscanApiKey : "YourApiKeyToken"}';
  
  // Cryptocurrency symbols for API requests
  static const Map<String, String> cryptoSymbols = {
    'BTC': 'BTC',
    'ETH': 'ETH',
    'DOGE': 'DOGE',
    'LTC': 'LTC',
    'DASH': 'DASH',
  };
  
  // Balance thresholds - minimum balance to record as a hit (in the respective cryptocurrency)
  static const Map<String, double> balanceThresholds = {
    'BTC': 0.00001,
    'ETH': 0.0001,
    'DOGE': 1.0,
    'LTC': 0.001,
    'DASH': 0.001,
  };
  
  // Default balance threshold
  static const double defaultBalanceThreshold = 0.000001;
}
