import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/wallet.dart';
import '../models/hit_log.dart';
import 'cryptography.dart';

class StorageService {
  late final CryptographyService _cryptographyService;
  late final SharedPreferences _prefs;
  static const String _hitLogKey = 'hit_log';
  static const String _settingsKey = 'settings';
  
  // Initialize the storage service
  Future<void> init() async {
    _cryptographyService = CryptographyService();
    await _cryptographyService.initialize();
    _prefs = await SharedPreferences.getInstance();
  }
  
  // Save a hit log to storage, encrypted
  Future<void> saveHitLog(HitLog hitLog) async {
    try {
      final json = jsonEncode(hitLog.toJson());
      final encrypted = await _cryptographyService.encrypt(json);
      await _prefs.setString(_hitLogKey, encrypted);
    } catch (e) {
      debugPrint('Error saving hit log: $e');
    }
  }
  
  // Load the hit log from storage, decrypt it
  Future<HitLog> loadHitLog() async {
    try {
      final encrypted = _prefs.getString(_hitLogKey);
      if (encrypted == null) {
        return HitLog();
      }
      
      final json = await _cryptographyService.decrypt(encrypted);
      final List<dynamic> decoded = jsonDecode(json);
      final List<Map<String, dynamic>> walletJsonList = decoded
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
      
      return HitLog.fromJson(walletJsonList);
    } catch (e) {
      debugPrint('Error loading hit log: $e');
      return HitLog();
    }
  }
  
  // Save app settings
  Future<void> saveSettings(Map<String, dynamic> settings) async {
    try {
      final json = jsonEncode(settings);
      await _prefs.setString(_settingsKey, json);
    } catch (e) {
      debugPrint('Error saving settings: $e');
    }
  }
  
  // Load app settings
  Future<Map<String, dynamic>> loadSettings() async {
    try {
      final json = _prefs.getString(_settingsKey);
      if (json == null) {
        return _getDefaultSettings();
      }
      
      return Map<String, dynamic>.from(jsonDecode(json));
    } catch (e) {
      debugPrint('Error loading settings: $e');
      return _getDefaultSettings();
    }
  }
  
  // Default settings
  Map<String, dynamic> _getDefaultSettings() {
    return {
      'darkMode': false,
      'backgroundScan': false,
      'balanceThresholds': {
        'BTC': 0.00001,
        'ETH': 0.0001,
        'DOGE': 1.0,
        'LTC': 0.001,
        'DASH': 0.001,
      },
      'scanDelay': 100, // milliseconds between scans
      'apiRateLimit': 5, // requests per second
    };
  }
  
  // Export hit log to a file
  Future<String?> exportHitLog() async {
    try {
      final hitLog = await loadHitLog();
      
      if (hitLog.hits.isEmpty) {
        return null;
      }
      
      final directory = await getExternalStorageDirectory();
      if (directory == null) {
        return null;
      }
      
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final path = '${directory.path}/wallet_hits_$timestamp.txt';
      
      final file = File(path);
      final buffer = StringBuffer();
      
      buffer.writeln('=== Wallet Discovery App - Hit Log ===');
      buffer.writeln('Exported: ${DateTime.now()}');
      buffer.writeln('Total hits: ${hitLog.hits.length}');
      buffer.writeln('======================================\n');
      
      for (int i = 0; i < hitLog.hits.length; i++) {
        final wallet = hitLog.hits[i];
        buffer.writeln('--- Wallet #${i + 1} ---');
        buffer.writeln('Private Key: ${wallet.privateKey}');
        buffer.writeln('Date Found: ${wallet.createdAt}');
        buffer.writeln('Addresses:');
        
        wallet.publicAddresses.forEach((type, address) {
          buffer.writeln('  $type: $address');
        });
        
        buffer.writeln('Balances:');
        wallet.balances.forEach((type, balance) {
          buffer.writeln('  $type: $balance');
        });
        
        buffer.writeln('');
      }
      
      await file.writeAsString(buffer.toString());
      return path;
    } catch (e) {
      debugPrint('Error exporting hit log: $e');
      return null;
    }
  }
}
