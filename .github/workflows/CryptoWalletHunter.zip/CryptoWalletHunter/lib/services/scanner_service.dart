import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/wallet.dart';
import '../models/hit_log.dart';
import 'wallet_generator.dart';
import 'balance_checker.dart';
import 'storage_service.dart';

class ScannerService extends ChangeNotifier {
  final WalletGenerator _walletGenerator = WalletGenerator();
  final BalanceCheckerService _balanceChecker = BalanceCheckerService();
  final StorageService _storageService;
  
  final HitLog _hitLog = HitLog();
  final ScanStats _stats = ScanStats();
  
  Timer? _progressUpdateTimer;
  
  // Thresholds for recording hits
  Map<CryptocurrencyType, double> _balanceThresholds = {};
  
  // Configuration
  bool _backgroundMode = false;
  int _numThreads = 1;
  int _scanDelay = 100; // milliseconds between key generation
  int _apiRateLimit = 5; // requests per second
  
  bool get isScanning => _stats.isScanning;
  bool get isPaused => _stats.isPaused;
  ScanStats get stats => _stats;
  HitLog get hitLog => _hitLog;
  
  bool get backgroundMode => _backgroundMode;
  
  Wallet? _lastFoundWallet;
  Wallet? get lastFoundWallet => _lastFoundWallet;
  
  StreamController<Wallet> _walletFoundController = StreamController<Wallet>.broadcast();
  Stream<Wallet> get walletFoundStream => _walletFoundController.stream;
  
  ScannerService(this._storageService) {
    _loadSettings();
    _loadHitLog();
  }
  
  // Load settings from storage
  Future<void> _loadSettings() async {
    final settings = await _storageService.loadSettings();
    
    _backgroundMode = settings['backgroundScan'] ?? false;
    _scanDelay = settings['scanDelay'] ?? 100;
    _apiRateLimit = settings['apiRateLimit'] ?? 5;
    
    // Load balance thresholds
    final thresholds = settings['balanceThresholds'];
    if (thresholds != null) {
      _balanceThresholds = {};
      for (final entry in thresholds.entries) {
        final type = _cryptoTypeFromString(entry.key);
        if (type != null) {
          _balanceThresholds[type] = entry.value.toDouble();
        }
      }
    }
    
    // Default to 1 thread, but allow up to 4 based on device capability
    _numThreads = 1;
  }
  
  // Convert string to CryptocurrencyType
  CryptocurrencyType? _cryptoTypeFromString(String value) {
    return CryptocurrencyType.values.firstWhere(
      (type) => type.toString() == 'CryptocurrencyType.$value',
      orElse: () => CryptocurrencyType.BTC,
    );
  }
  
  // Load hit log from storage
  Future<void> _loadHitLog() async {
    final savedHitLog = await _storageService.loadHitLog();
    _hitLog.hits.addAll(savedHitLog.hits);
    notifyListeners();
  }
  
  // Start wallet scanning
  Future<void> startScanning() async {
    if (_stats.isScanning && !_stats.isPaused) {
      return;
    }
    
    if (_stats.isPaused) {
      _stats.resume();
      notifyListeners();
      return;
    }
    
    _stats.reset();
    _stats.start();
    _lastFoundWallet = null;
    
    // Start periodic update of UI
    _progressUpdateTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      notifyListeners();
    });
    
    // For simplicity, we're just using single-threaded scanning for now
    _scanWallets();
    
    notifyListeners();
  }
  
  // Main scanning loop
  Future<void> _scanWallets() async {
    while (_stats.isScanning && !_stats.isPaused) {
      // Generate a random private key
      final privateKey = _walletGenerator.generatePrivateKey();
      
      // Generate wallet with addresses
      final wallet = await _walletGenerator.generateWalletFromPrivateKey(privateKey);
      
      // Check balances
      final balances = await _balanceChecker.checkAllBalances(wallet);
      
      // Update wallet with balances
      final walletWithBalances = Wallet(
        privateKey: wallet.privateKey,
        publicAddresses: wallet.publicAddresses,
        balances: balances,
      );
      
      // Process the wallet
      _processWallet(walletWithBalances);
      
      // Increment counter
      _stats.keysChecked++;
      
      // Add delay to avoid overwhelming APIs
      await Future.delayed(Duration(milliseconds: _scanDelay));
    }
  }
  
  // Process a wallet after checking its balance
  void _processWallet(Wallet wallet) {
    bool hasBalance = false;
    
    // Check if any balance exceeds threshold
    for (final entry in wallet.balances.entries) {
      final threshold = _balanceThresholds[entry.key] ?? 0.000001;
      if (entry.value > threshold) {
        hasBalance = true;
        break;
      }
    }
    
    if (hasBalance) {
      _processFoundWallet(wallet);
    }
  }
  
  // Handle a wallet with non-zero balance
  void _processFoundWallet(Wallet wallet) {
    _hitLog.addHit(wallet);
    _stats.hitsFound++;
    _lastFoundWallet = wallet;
    
    // Save the hit log
    _storageService.saveHitLog(_hitLog);
    
    // Notify listeners of found wallet
    _walletFoundController.add(wallet);
    
    // Stop scanning if wallet has significant balance
    bool hasSeriousBalance = false;
    for (final entry in wallet.balances.entries) {
      final threshold = (_balanceThresholds[entry.key] ?? 0.000001) * 10;
      if (entry.value > threshold) {
        hasSeriousBalance = true;
        break;
      }
    }
    
    if (hasSeriousBalance) {
      stopScanning();
    }
    
    notifyListeners();
  }
  
  // Pause wallet scanning
  void pauseScanning() {
    if (_stats.isScanning && !_stats.isPaused) {
      _stats.pause();
      notifyListeners();
    }
  }
  
  // Stop wallet scanning
  Future<void> stopScanning() async {
    if (_stats.isScanning) {
      _stats.stop();
      
      // Stop update timer
      _progressUpdateTimer?.cancel();
      
      notifyListeners();
    }
  }
  
  // Update scanner settings
  Future<void> updateSettings({
    bool? backgroundMode,
    int? scanDelay,
    int? apiRateLimit,
    Map<CryptocurrencyType, double>? thresholds,
  }) async {
    if (backgroundMode != null) {
      _backgroundMode = backgroundMode;
    }
    
    if (scanDelay != null) {
      _scanDelay = scanDelay;
    }
    
    if (apiRateLimit != null) {
      _apiRateLimit = apiRateLimit;
    }
    
    if (thresholds != null) {
      _balanceThresholds = thresholds;
    }
    
    // Save settings
    final settings = {
      'backgroundScan': _backgroundMode,
      'scanDelay': _scanDelay,
      'apiRateLimit': _apiRateLimit,
      'balanceThresholds': _balanceThresholds.map((k, v) => MapEntry(k.toString().split('.').last, v)),
    };
    
    await _storageService.saveSettings(settings);
    notifyListeners();
  }
  
  // Export hits to a file
  Future<String?> exportHits() async {
    return _storageService.exportHitLog();
  }
  
  // Clear hit log
  Future<void> clearHitLog() async {
    _hitLog.clear();
    await _storageService.saveHitLog(_hitLog);
    notifyListeners();
  }
  
  // Load private keys from a file and scan them
  Future<void> scanFromFile(String filePath) async {
    if (_stats.isScanning) {
      await stopScanning();
    }
    
    final privateKeys = await _walletGenerator.loadPrivateKeysFromFile(filePath);
    
    if (privateKeys.isEmpty) {
      return;
    }
    
    _stats.reset();
    _stats.start();
    
    // Start periodic update of UI
    _progressUpdateTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      notifyListeners();
    });
    
    for (final privateKey in privateKeys) {
      if (!_stats.isScanning || _stats.isPaused) {
        break;
      }
      
      // Generate wallet
      final wallet = await _walletGenerator.generateWalletFromPrivateKey(privateKey);
      
      // Check balances
      final balances = await _balanceChecker.checkAllBalances(wallet);
      
      // Update wallet with balances
      final walletWithBalances = Wallet(
        privateKey: wallet.privateKey,
        publicAddresses: wallet.publicAddresses,
        balances: balances,
      );
      
      // Process the wallet
      _processWallet(walletWithBalances);
      
      // Increment counter
      _stats.keysChecked++;
      notifyListeners();
      
      // Add delay to avoid overwhelming APIs
      await Future.delayed(Duration(milliseconds: _scanDelay));
    }
    
    _stats.stop();
    _progressUpdateTimer?.cancel();
    notifyListeners();
  }
  
  @override
  void dispose() {
    _progressUpdateTimer?.cancel();
    stopScanning();
    _walletFoundController.close();
    super.dispose();
  }
}
