import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:convert/convert.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter/foundation.dart';

class CryptographyService {
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  final String _encryptionKeyName = 'wallet_discovery_encryption_key';
  late String _encryptionKey;
  
  // Initialize the service by getting or generating an encryption key
  Future<void> initialize() async {
    try {
      // Try to retrieve the encryption key
      String? storedKey = await _secureStorage.read(key: _encryptionKeyName);
      
      if (storedKey == null) {
        // Generate a new encryption key if none exists
        _encryptionKey = _generateEncryptionKey();
        await _secureStorage.write(key: _encryptionKeyName, value: _encryptionKey);
      } else {
        _encryptionKey = storedKey;
      }
    } catch (e) {
      debugPrint('Error initializing cryptography service: $e');
      // Fallback to a derived key if secure storage fails
      _encryptionKey = _deriveFallbackKey();
    }
  }
  
  // Generate a random encryption key
  String _generateEncryptionKey() {
    final values = List<int>.generate(32, (i) => i + 1);
    values.shuffle();
    return base64.encode(Uint8List.fromList(values.take(32).toList()));
  }
  
  // Derive a fallback key (less secure but better than nothing)
  String _deriveFallbackKey() {
    final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    final bytes = utf8.encode(timestamp + 'wallet_discovery_app_salt');
    final digest = sha256.convert(bytes);
    return digest.toString();
  }
  
  // Encrypt data using a simple XOR cipher (simplified for demonstration)
  Future<String> encrypt(String data) async {
    try {
      // Get a key from the encryption key
      final keyBytes = sha256.convert(utf8.encode(_encryptionKey)).bytes;
      final encoded = _xorEncrypt(utf8.encode(data), keyBytes);
      return base64.encode(encoded);
    } catch (e) {
      debugPrint('Encryption error: $e');
      return base64.encode(utf8.encode(data)); // Simple encoding as fallback
    }
  }
  
  // Decrypt data
  Future<String> decrypt(String encryptedData) async {
    try {
      final bytes = base64.decode(encryptedData);
      final keyBytes = sha256.convert(utf8.encode(_encryptionKey)).bytes;
      final decoded = _xorEncrypt(bytes, keyBytes); // XOR is its own inverse
      return utf8.decode(decoded);
    } catch (e) {
      debugPrint('Decryption error: $e');
      return encryptedData; // Return encrypted data on error
    }
  }
  
  // Simple XOR encryption
  List<int> _xorEncrypt(List<int> data, List<int> key) {
    List<int> result = List<int>.filled(data.length, 0);
    for (int i = 0; i < data.length; i++) {
      result[i] = data[i] ^ key[i % key.length];
    }
    return result;
  }
  
  // Hash a string using SHA-256
  String hash(String input) {
    final bytes = utf8.encode(input);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }
  
  // Generate a deterministic key from a seed
  String generateDeterministicKey(String seed) {
    final bytes = utf8.encode(seed);
    final digest = sha256.convert(bytes);
    return hex.encode(digest.bytes);
  }
}
