import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '../models/wallet.dart';
import '../constants/api_constants.dart';

class BalanceCheckerService {
  // Check balances for all crypto types in a wallet
  Future<Map<CryptocurrencyType, double>> checkAllBalances(Wallet wallet) async {
    final Map<CryptocurrencyType, double> balances = {};
    
    for (final cryptoType in CryptocurrencyType.values) {
      try {
        final address = wallet.publicAddresses[cryptoType];
        if (address != null) {
          // Try primary API method first
          double balance = await _checkBalancePrimary(address, cryptoType);
          
          // If primary fails, try backup API method
          if (balance < 0) {
            balance = await _checkBalanceBackup(address, cryptoType);
          }
          
          // If both methods fail, set balance to 0
          if (balance < 0) {
            balance = 0;
          }
          
          balances[cryptoType] = balance;
        }
      } catch (e) {
        debugPrint('Error checking balance for $cryptoType: $e');
        balances[cryptoType] = 0;
      }
    }
    
    return balances;
  }
  
  // Primary API method for checking balances
  Future<double> _checkBalancePrimary(String address, CryptocurrencyType type) async {
    try {
      switch (type) {
        case CryptocurrencyType.BTC:
          return await _checkBitcoinBalanceSoChain(address);
        case CryptocurrencyType.ETH:
          return await _checkEthereumBalanceEtherscan(address);
        case CryptocurrencyType.DOGE:
          return await _checkDogecoinBalanceSoChain(address);
        case CryptocurrencyType.LTC:
          return await _checkLitecoinBalanceSoChain(address);
        case CryptocurrencyType.DASH:
          return await _checkDashBalanceSoChain(address);
        default:
          return -1;
      }
    } catch (e) {
      debugPrint('Primary balance check failed for $type: $e');
      return -1;
    }
  }
  
  // Backup API method for checking balances
  Future<double> _checkBalanceBackup(String address, CryptocurrencyType type) async {
    try {
      switch (type) {
        case CryptocurrencyType.BTC:
          return await _checkBitcoinBalanceBlockchair(address);
        case CryptocurrencyType.ETH:
          return await _checkEthereumBalanceBlockchair(address);
        case CryptocurrencyType.DOGE:
          return await _checkDogecoinBalanceBlockchair(address);
        case CryptocurrencyType.LTC:
          return await _checkLitecoinBalanceBlockchair(address);
        case CryptocurrencyType.DASH:
          return await _checkDashBalanceBlockchair(address);
        default:
          return -1;
      }
    } catch (e) {
      debugPrint('Backup balance check failed for $type: $e');
      return -1;
    }
  }
  
  // Bitcoin balance check using SoChain API
  Future<double> _checkBitcoinBalanceSoChain(String address) async {
    final url = ApiConstants.sochainAddressBalance('BTC', address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == 'success') {
        final balance = double.tryParse(jsonResponse['data']['confirmed_balance'] ?? '0') ?? 0;
        return balance;
      }
    }
    return -1;
  }
  
  // Ethereum balance check using Etherscan API
  Future<double> _checkEthereumBalanceEtherscan(String address) async {
    final url = ApiConstants.etherscanBalance(address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == '1') {
        // Convert wei to ether (1 ether = 10^18 wei)
        final balanceWei = BigInt.tryParse(jsonResponse['result'] ?? '0') ?? BigInt.zero;
        final balance = balanceWei / BigInt.from(10).pow(18);
        return balance.toDouble();
      }
    }
    return -1;
  }
  
  // Dogecoin balance check using SoChain API
  Future<double> _checkDogecoinBalanceSoChain(String address) async {
    final url = ApiConstants.sochainAddressBalance('DOGE', address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == 'success') {
        final balance = double.tryParse(jsonResponse['data']['confirmed_balance'] ?? '0') ?? 0;
        return balance;
      }
    }
    return -1;
  }
  
  // Litecoin balance check using SoChain API
  Future<double> _checkLitecoinBalanceSoChain(String address) async {
    final url = ApiConstants.sochainAddressBalance('LTC', address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == 'success') {
        final balance = double.tryParse(jsonResponse['data']['confirmed_balance'] ?? '0') ?? 0;
        return balance;
      }
    }
    return -1;
  }
  
  // Dash balance check using SoChain API
  Future<double> _checkDashBalanceSoChain(String address) async {
    final url = ApiConstants.sochainAddressBalance('DASH', address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == 'success') {
        final balance = double.tryParse(jsonResponse['data']['confirmed_balance'] ?? '0') ?? 0;
        return balance;
      }
    }
    return -1;
  }
  
  // Bitcoin balance check using Blockchair API
  Future<double> _checkBitcoinBalanceBlockchair(String address) async {
    final url = ApiConstants.blockchairBitcoinBalance(address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['context']['code'] == 200) {
        final data = jsonResponse['data'][address];
        if (data != null) {
          final balanceSats = data['address']['balance'] ?? 0;
          return balanceSats / 100000000; // Convert from satoshis to BTC
        }
      }
    }
    return -1;
  }
  
  // Ethereum balance check using Blockchair API
  Future<double> _checkEthereumBalanceBlockchair(String address) async {
    final url = ApiConstants.blockchairEthereumBalance(address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['context']['code'] == 200) {
        final data = jsonResponse['data'][address.toLowerCase()];
        if (data != null) {
          final balanceWei = data['address']['balance'] ?? 0;
          return balanceWei / 1e18; // Convert from wei to ETH
        }
      }
    }
    return -1;
  }
  
  // Dogecoin balance check using Blockchair API
  Future<double> _checkDogecoinBalanceBlockchair(String address) async {
    final url = ApiConstants.blockchairDogecoinBalance(address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['context']['code'] == 200) {
        final data = jsonResponse['data'][address];
        if (data != null) {
          final balanceKoinu = data['address']['balance'] ?? 0;
          return balanceKoinu / 100000000; // Convert from koinu to DOGE
        }
      }
    }
    return -1;
  }
  
  // Litecoin balance check using Blockchair API
  Future<double> _checkLitecoinBalanceBlockchair(String address) async {
    final url = ApiConstants.blockchairLitecoinBalance(address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['context']['code'] == 200) {
        final data = jsonResponse['data'][address];
        if (data != null) {
          final balanceLitoshis = data['address']['balance'] ?? 0;
          return balanceLitoshis / 100000000; // Convert from litoshis to LTC
        }
      }
    }
    return -1;
  }
  
  // Dash balance check using Blockchair API
  Future<double> _checkDashBalanceBlockchair(String address) async {
    final url = ApiConstants.blockchairDashBalance(address);
    final response = await http.get(Uri.parse(url));
    
    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['context']['code'] == 200) {
        final data = jsonResponse['data'][address];
        if (data != null) {
          final balanceDuffs = data['address']['balance'] ?? 0;
          return balanceDuffs / 100000000; // Convert from duffs to DASH
        }
      }
    }
    return -1;
  }
  
  // Check if a wallet has a balance above the threshold
  bool isAboveThreshold(Wallet wallet, Map<CryptocurrencyType, double> thresholds) {
    for (final entry in wallet.balances.entries) {
      final cryptoType = entry.key;
      final balance = entry.value;
      final threshold = thresholds[cryptoType] ?? ApiConstants.defaultBalanceThreshold;
      
      if (balance > threshold) {
        return true;
      }
    }
    return false;
  }
}
