import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:web3dart/web3dart.dart';
import 'package:hex/hex.dart';
import 'package:flutter/foundation.dart';
import 'package:bip32/bip32.dart' as bip32;
import '../models/wallet.dart';

class AddressDerivation {
  // Base58 encoding alphabet
  static const String _alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  
  // Network version bytes
  static const int _btcPubkeyHash = 0x00; // Bitcoin P2PKH address
  static const int _dogePubkeyHash = 0x1E; // Dogecoin P2PKH address
  static const int _ltcPubkeyHash = 0x30; // Litecoin P2PKH address
  static const int _dashPubkeyHash = 0x4C; // Dash P2PKH address

  // Derive a cryptocurrency address from a private key
  Future<String> deriveAddress(String privateKey, CryptocurrencyType type) async {
    try {
      switch (type) {
        case CryptocurrencyType.BTC:
          return _deriveBitcoinAddress(privateKey);
        case CryptocurrencyType.ETH:
          return _deriveEthereumAddress(privateKey);
        case CryptocurrencyType.DOGE:
          return _deriveDogecoinAddress(privateKey);
        case CryptocurrencyType.LTC:
          return _deriveLitecoinAddress(privateKey);
        case CryptocurrencyType.DASH:
          return _deriveDashAddress(privateKey);
        default:
          throw Exception('Unsupported cryptocurrency type');
      }
    } catch (e) {
      debugPrint('Error deriving address for $type: $e');
      return 'Error: Failed to derive address';
    }
  }
  
  // Derive a Bitcoin address
  String _deriveBitcoinAddress(String privateKey) {
    return _deriveAddressFromPrivateKey(privateKey, _btcPubkeyHash);
  }
  
  // Derive an Ethereum address
  String _deriveEthereumAddress(String privateKey) {
    final EthPrivateKey credentials = EthPrivateKey.fromHex(privateKey);
    final EthereumAddress address = credentials.address;
    return address.hexEip55;
  }
  
  // Derive a Dogecoin address
  String _deriveDogecoinAddress(String privateKey) {
    return _deriveAddressFromPrivateKey(privateKey, _dogePubkeyHash);
  }
  
  // Derive a Litecoin address
  String _deriveLitecoinAddress(String privateKey) {
    return _deriveAddressFromPrivateKey(privateKey, _ltcPubkeyHash);
  }
  
  // Derive a Dash address
  String _deriveDashAddress(String privateKey) {
    return _deriveAddressFromPrivateKey(privateKey, _dashPubkeyHash);
  }
  
  // Common method to derive addresses for Bitcoin-like cryptocurrencies
  String _deriveAddressFromPrivateKey(String privateKey, int versionByte) {
    try {
      // Convert private key from hex to bytes
      final Uint8List privKeyBytes = Uint8List.fromList(HEX.decode(privateKey));
      
      // Create BIP32 node from private key
      final node = bip32.BIP32.fromPrivateKey(
        privKeyBytes,
        Uint8List(32), // Using empty chain code for simplicity
      );
      
      // Get public key (compressed format)
      final publicKey = node.publicKey;
      
      // Hash public key with SHA-256 and then RIPEMD-160
      final sha256Hash = sha256.convert(publicKey).bytes;
      final ripemd160Hash = Uint8List.fromList(
        _ripemd160(Uint8List.fromList(sha256Hash))
      );
      
      // Add version byte
      final extendedRipemd160Hash = Uint8List(ripemd160Hash.length + 1);
      extendedRipemd160Hash[0] = versionByte;
      for (int i = 0; i < ripemd160Hash.length; i++) {
        extendedRipemd160Hash[i + 1] = ripemd160Hash[i];
      }
      
      // Calculate checksum (first 4 bytes of double SHA-256)
      final checksum = _calculateChecksum(extendedRipemd160Hash);
      
      // Combine extended hash and checksum
      final addressBytes = Uint8List(extendedRipemd160Hash.length + 4);
      for (int i = 0; i < extendedRipemd160Hash.length; i++) {
        addressBytes[i] = extendedRipemd160Hash[i];
      }
      
      for (int i = 0; i < 4; i++) {
        addressBytes[extendedRipemd160Hash.length + i] = checksum[i];
      }
      
      // Encode with Base58
      return _base58Encode(addressBytes);
    } catch (e) {
      debugPrint('Error in address derivation: $e');
      return 'Error: Failed to derive address';
    }
  }
  
  // RIPEMD-160
  Uint8List _ripemd160(Uint8List data) {
    // A simplified implementation of RIPEMD-160 using a double SHA-256
    // In a production app, use a proper crypto library for RIPEMD-160
    final sha1 = sha256.convert(sha256.convert(data).bytes).bytes.sublist(0, 20);
    return Uint8List.fromList(sha1);
  }
  
  // Calculate checksum (first 4 bytes of double SHA-256)
  Uint8List _calculateChecksum(Uint8List data) {
    final hash1 = sha256.convert(data);
    final hash2 = sha256.convert(hash1.bytes);
    return Uint8List.fromList(hash2.bytes.sublist(0, 4));
  }
  
  // Base58 encoding
  String _base58Encode(Uint8List data) {
    // Convert to BigInt
    BigInt value = BigInt.zero;
    for (final byte in data) {
      value = value * BigInt.from(256) + BigInt.from(byte);
    }
    
    // Encode with Base58
    String result = '';
    final base = BigInt.from(_alphabet.length);
    
    while (value > BigInt.zero) {
      final remainder = value % base;
      value = value ~/ base;
      result = _alphabet[remainder.toInt()] + result;
    }
    
    // Add leading '1's for leading zeros
    for (int i = 0; i < data.length && data[i] == 0; i++) {
      result = '1' + result;
    }
    
    return result;
  }
}
