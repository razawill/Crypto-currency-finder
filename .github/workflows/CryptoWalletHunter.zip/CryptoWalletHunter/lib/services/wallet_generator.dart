import 'dart:typed_data';
import 'dart:math';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:hex/hex.dart';
import 'package:flutter/foundation.dart';
import 'package:bip32/bip32.dart' as bip32;
import 'package:bip39/bip39.dart' as bip39;
import '../models/wallet.dart';
import 'address_derivation.dart';

class WalletGenerator {
  final AddressDerivation _addressDerivation = AddressDerivation();
  final Random _secureRandom = Random.secure();
  
  // Generate a single random private key
  String generatePrivateKey() {
    const int privateKeyLength = 32; // 256 bits
    final Uint8List randomBytes = Uint8List(privateKeyLength);
    
    for (var i = 0; i < privateKeyLength; i++) {
      randomBytes[i] = _secureRandom.nextInt(256);
    }
    
    // Ensure that the private key is valid for curve secp256k1
    final String hexKey = HEX.encode(randomBytes);
    
    // Check if key is valid (not zero, less than curve order)
    final BigInt privateKeyInt = BigInt.parse(hexKey, radix: 16);
    final BigInt curveOrder = BigInt.parse('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141', radix: 16);
    
    if (privateKeyInt == BigInt.zero || privateKeyInt >= curveOrder) {
      // Recursively generate another key if this one is invalid
      return generatePrivateKey();
    }
    
    return hexKey;
  }
  
  // Generate a wallet including all cryptocurrency addresses from a private key
  Future<Wallet> generateWalletFromPrivateKey(String privateKey) async {
    final Map<CryptocurrencyType, String> addresses = {};
    
    // Derive addresses for each cryptocurrency
    for (final cryptoType in CryptocurrencyType.values) {
      final address = await _addressDerivation.deriveAddress(privateKey, cryptoType);
      addresses[cryptoType] = address;
    }
    
    return Wallet(
      privateKey: privateKey,
      publicAddresses: addresses,
    );
  }
  
  // Calculate a hash of the private key for checking duplicates
  String getKeyIdentifier(String privateKey) {
    final bytes = Uint8List.fromList(HEX.decode(privateKey));
    final digest = sha256.convert(bytes);
    return digest.toString();
  }
  
  // Load private keys from a file
  Future<List<String>> loadPrivateKeysFromFile(String filePath) async {
    try {
      final File file = File(filePath);
      if (!await file.exists()) {
        throw Exception('File does not exist');
      }
      
      final String content = await file.readAsString();
      final List<String> lines = content.split('\n');
      final List<String> privateKeys = [];
      
      for (String line in lines) {
        line = line.trim();
        
        // Skip empty lines
        if (line.isEmpty) continue;
        
        // Validate private key format (hexadecimal, correct length)
        if (_isValidPrivateKeyFormat(line)) {
          privateKeys.add(line);
        }
      }
      
      return privateKeys;
    } catch (e) {
      debugPrint('Error loading private keys: $e');
      return [];
    }
  }
  
  // Validate private key format (simple check)
  bool _isValidPrivateKeyFormat(String key) {
    // Check if it's a valid hex string of 64 characters (32 bytes)
    final RegExp hexRegex = RegExp(r'^[0-9a-fA-F]{64}$');
    return hexRegex.hasMatch(key);
  }
}
