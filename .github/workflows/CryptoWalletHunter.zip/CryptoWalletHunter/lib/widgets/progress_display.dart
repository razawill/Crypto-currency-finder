import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/scanner_service.dart';

class ProgressDisplay extends StatelessWidget {
  const ProgressDisplay({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<ScannerService>(
      builder: (context, scannerService, child) {
        final stats = scannerService.stats;
        final isScanning = stats.isScanning;
        final isPaused = stats.isPaused;
        
        final duration = stats.duration;
        final minutes = duration.inMinutes;
        final seconds = duration.inSeconds % 60;
        final formattedTime = '$minutes:${seconds.toString().padLeft(2, '0')}';
        
        final keysPerSecond = stats.keysPerSecond;
        final formattedSpeed = keysPerSecond.toStringAsFixed(2);
        
        return Column(
          children: [
            // Status indicator
            Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              decoration: BoxDecoration(
                color: isScanning
                    ? isPaused
                        ? Colors.orange
                        : Colors.green
                    : Colors.grey,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    isScanning
                        ? isPaused
                            ? Icons.pause
                            : Icons.search
                        : Icons.search_off,
                    color: Colors.white,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    isScanning
                        ? isPaused
                            ? 'PAUSED'
                            : 'SCANNING'
                        : 'IDLE',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Stats grid
            Row(
              children: [
                _buildStatCard(
                  context: context,
                  title: 'Keys Checked',
                  value: '${stats.keysChecked}',
                  icon: Icons.key,
                ),
                const SizedBox(width: 8),
                _buildStatCard(
                  context: context,
                  title: 'Hits Found',
                  value: '${stats.hitsFound}',
                  icon: Icons.check_circle,
                  color: Colors.green,
                ),
              ],
            ),
            
            const SizedBox(height: 8),
            
            Row(
              children: [
                _buildStatCard(
                  context: context,
                  title: 'Scan Time',
                  value: formattedTime,
                  icon: Icons.timer,
                ),
                const SizedBox(width: 8),
                _buildStatCard(
                  context: context,
                  title: 'Keys/Second',
                  value: formattedSpeed,
                  icon: Icons.speed,
                ),
              ],
            ),
            
            // Progress indicator
            if (isScanning && !isPaused)
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: LinearProgressIndicator(
                  value: null, // Indeterminate
                  backgroundColor: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade800
                      : Colors.grey.shade300,
                ),
              ),
          ],
        );
      },
    );
  }
  
  Widget _buildStatCard({
    required BuildContext context, 
    required String title, 
    required String value, 
    required IconData icon,
    Color? color,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.grey.shade800
              : Colors.grey.shade200,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: color ?? Theme.of(context).primaryColor,
              size: 20,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.grey.shade400
                          : Colors.grey.shade700,
                    ),
                  ),
                  Text(
                    value,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: color,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
