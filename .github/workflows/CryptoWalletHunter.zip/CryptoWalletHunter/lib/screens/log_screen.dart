import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/scanner_service.dart';
import '../services/storage_service.dart';
import '../models/wallet.dart';
import '../widgets/wallet_card.dart';

class LogScreen extends StatefulWidget {
  const LogScreen({Key? key}) : super(key: key);

  @override
  _LogScreenState createState() => _LogScreenState();
}

class _LogScreenState extends State<LogScreen> {
  late ScannerService _scannerService;
  
  @override
  void initState() {
    super.initState();
    final storageService = Provider.of<StorageService>(context, listen: false);
    _scannerService = ScannerService(storageService);
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wallet Hits'),
        actions: [
          IconButton(
            icon: const Icon(Icons.file_download),
            onPressed: _scannerService.hitLog.hits.isEmpty
                ? null
                : () async {
                    final path = await _scannerService.exportHits();
                    if (path != null && mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Exported to: $path'),
                          backgroundColor: Colors.green,
                        ),
                      );
                    } else if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Failed to export hit log'),
                          backgroundColor: Colors.red,
                        ),
                      );
                    }
                  },
            tooltip: 'Export hits',
          ),
        ],
      ),
      body: ChangeNotifierProvider.value(
        value: _scannerService,
        child: Consumer<ScannerService>(
          builder: (context, scannerService, child) {
            if (scannerService.hitLog.hits.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.search_off, size: 64, color: Colors.grey),
                    const SizedBox(height: 16),
                    Text(
                      'No wallet hits found yet',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Start scanning to discover wallets with balance',
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text('Back to Scanner'),
                    ),
                  ],
                ),
              );
            }
            
            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: scannerService.hitLog.hits.length,
              itemBuilder: (context, index) {
                final hit = scannerService.hitLog.hits[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: WalletCard(
                    wallet: hit,
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        '/result',
                        arguments: hit,
                      );
                    },
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
