import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import '../services/scanner_service.dart';
import '../services/storage_service.dart';
import '../models/wallet.dart';
import '../theme/theme_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late ScannerService _scannerService;
  Map<CryptocurrencyType, double> _thresholds = {};
  
  final Map<CryptocurrencyType, TextEditingController> _thresholdControllers = {};
  
  bool _backgroundMode = false;
  int _scanDelay = 100;
  
  @override
  void initState() {
    super.initState();
    final storageService = Provider.of<StorageService>(context, listen: false);
    _scannerService = ScannerService(storageService);
    
    // Initialize controllers for each cryptocurrency
    for (final type in CryptocurrencyType.values) {
      _thresholdControllers[type] = TextEditingController();
    }
    
    _loadSettings();
  }
  
  Future<void> _loadSettings() async {
    final settings = await _scannerService.hitLog;
    
    setState(() {
      _backgroundMode = _scannerService.backgroundMode;
      
      // Load thresholds from settings
      for (final type in CryptocurrencyType.values) {
        _thresholds[type] = 0.000001; // Default threshold
        _thresholdControllers[type]?.text = _thresholds[type].toString();
      }
    });
  }
  
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Theme Settings
            Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Appearance',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    SwitchListTile(
                      title: const Text('Dark Mode'),
                      subtitle: const Text('Enable dark theme'),
                      value: themeProvider.themeMode == ThemeMode.dark,
                      onChanged: (value) {
                        themeProvider.toggleTheme();
                      },
                    ),
                  ],
                ),
              ),
            ),
            
            // Scanner Settings
            Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Scanner Settings',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    SwitchListTile(
                      title: const Text('Background Scan Mode'),
                      subtitle: const Text('Continue scanning when app is in background'),
                      value: _backgroundMode,
                      onChanged: (value) {
                        setState(() {
                          _backgroundMode = value;
                        });
                        _scannerService.updateSettings(backgroundMode: value);
                      },
                    ),
                    ListTile(
                      title: const Text('Scan Delay'),
                      subtitle: Text('$_scanDelay ms between key checks'),
                      trailing: SizedBox(
                        width: 130,
                        child: Slider(
                          min: 10,
                          max: 1000,
                          divisions: 99,
                          value: _scanDelay.toDouble(),
                          label: '$_scanDelay ms',
                          onChanged: (value) {
                            setState(() {
                              _scanDelay = value.round();
                            });
                          },
                          onChangeEnd: (value) {
                            _scannerService.updateSettings(scanDelay: value.round());
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            // Balance Thresholds
            Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Balance Thresholds',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Minimum balance required to log a wallet as a hit',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 16),
                    ...CryptocurrencyType.values.map((type) {
                      final controller = _thresholdControllers[type];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 80,
                              child: Text(
                                type.toString().split('.').last,
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ),
                            Expanded(
                              child: TextFormField(
                                controller: controller,
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                inputFormatters: [
                                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*$')),
                                ],
                                decoration: const InputDecoration(
                                  isDense: true,
                                  hintText: 'Min. balance',
                                ),
                                onChanged: (value) {
                                  final threshold = double.tryParse(value) ?? 0.000001;
                                  _thresholds[type] = threshold;
                                  _scannerService.updateSettings(thresholds: _thresholds);
                                },
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ],
                ),
              ),
            ),
            
            // Import Keys
            Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Import Private Keys',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Scan from a list of pre-defined private keys',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      icon: const Icon(Icons.file_upload),
                      label: const Text('Select Key File'),
                      onPressed: () async {
                        final result = await FilePicker.platform.pickFiles(
                          type: FileType.custom,
                          allowedExtensions: ['txt'],
                        );
                        
                        if (result != null && result.files.single.path != null) {
                          final filePath = result.files.single.path!;
                          
                          // Show confirmation dialog
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: const Text('Scan Private Keys'),
                              content: Text('Start scanning keys from ${result.files.single.name}?'),
                              actions: [
                                TextButton(
                                  child: const Text('Cancel'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                ),
                                ElevatedButton(
                                  child: const Text('Scan'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                    Navigator.of(context).pop(); // Close settings
                                    _scannerService.scanFromFile(filePath);
                                  },
                                ),
                              ],
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
            
            // Data Management
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Data Management',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    ListTile(
                      leading: const Icon(Icons.delete_forever, color: Colors.red),
                      title: const Text('Clear Hit Log'),
                      subtitle: const Text('Delete all saved wallet hits'),
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: const Text('Clear Hit Log'),
                            content: const Text('Are you sure you want to delete all saved wallet hits? This action cannot be undone.'),
                            actions: [
                              TextButton(
                                child: const Text('Cancel'),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              ),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.red,
                                ),
                                child: const Text('Delete All'),
                                onPressed: () {
                                  _scannerService.clearHitLog();
                                  Navigator.of(context).pop();
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Hit log cleared'),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.file_download),
                      title: const Text('Export Hit Log'),
                      subtitle: const Text('Save all wallet hits to a file'),
                      onTap: () async {
                        final path = await _scannerService.exportHits();
                        if (path != null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Exported to: $path'),
                              backgroundColor: Colors.green,
                            ),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Failed to export hit log'),
                              backgroundColor: Colors.red,
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  @override
  void dispose() {
    // Dispose controllers
    for (final controller in _thresholdControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }
}
