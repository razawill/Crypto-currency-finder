import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/wallet.dart';

class ResultScreen extends StatefulWidget {
  const ResultScreen({Key? key}) : super(key: key);

  @override
  _ResultScreenState createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  @override
  Widget build(BuildContext context) {
    final wallet = ModalRoute.of(context)!.settings.arguments as Wallet?;
    
    if (wallet == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Wallet Details'),
        ),
        body: const Center(
          child: Text('No wallet data available'),
        ),
      );
    }
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wallet Details'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Private Key',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        IconButton(
                          icon: const Icon(Icons.copy),
                          onPressed: () {
                            Clipboard.setData(ClipboardData(text: wallet.privateKey));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Private key copied to clipboard'),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          },
                          tooltip: 'Copy to clipboard',
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.black54
                            : Colors.grey[200],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: SelectableText(
                        wallet.privateKey,
                        style: const TextStyle(fontFamily: 'monospace'),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Found on: ${wallet.createdAt.toString().split('.').first}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            ),
            
            // Balances Section
            Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Balances',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    ...CryptocurrencyType.values.map((type) {
                      final balance = wallet.balances[type] ?? 0.0;
                      final isPositive = balance > 0;
                      
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                _getCryptoIcon(type),
                                const SizedBox(width: 8),
                                Text(
                                  type.toString().split('.').last,
                                  style: Theme.of(context).textTheme.titleMedium,
                                ),
                              ],
                            ),
                            Text(
                              '$balance',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: isPositive ? Colors.green : null,
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ],
                ),
              ),
            ),
            
            // Addresses Section
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Public Addresses',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    ...CryptocurrencyType.values.map((type) {
                      final address = wallet.publicAddresses[type] ?? 'N/A';
                      
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                _getCryptoIcon(type),
                                const SizedBox(width: 8),
                                Text(
                                  type.toString().split('.').last,
                                  style: Theme.of(context).textTheme.titleMedium,
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).brightness == Brightness.dark
                                          ? Colors.black54
                                          : Colors.grey[200],
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: SelectableText(
                                      address,
                                      style: const TextStyle(fontFamily: 'monospace'),
                                    ),
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.copy),
                                  onPressed: () {
                                    Clipboard.setData(ClipboardData(text: address));
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('${type.toString().split('.').last} address copied'),
                                        duration: const Duration(seconds: 2),
                                      ),
                                    );
                                  },
                                  tooltip: 'Copy to clipboard',
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _getCryptoIcon(CryptocurrencyType type) {
    IconData iconData;
    Color color;
    
    switch (type) {
      case CryptocurrencyType.BTC:
        iconData = Icons.currency_bitcoin;
        color = Colors.orange;
        break;
      case CryptocurrencyType.ETH:
        iconData = Icons.currency_exchange;
        color = Colors.blue;
        break;
      case CryptocurrencyType.DOGE:
        iconData = Icons.pets;
        color = Colors.amber;
        break;
      case CryptocurrencyType.LTC:
        iconData = Icons.attach_money;
        color = Colors.grey;
        break;
      case CryptocurrencyType.DASH:
        iconData = Icons.speed;
        color = Colors.blue;
        break;
    }
    
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Icon(
        iconData,
        color: color,
        size: 20,
      ),
    );
  }
}
