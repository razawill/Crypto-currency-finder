enum CryptocurrencyType {
  BTC,
  ETH,
  DOGE,
  LTC,
  DASH
}

class Wallet {
  final String privateKey;
  final Map<CryptocurrencyType, String> publicAddresses;
  final Map<CryptocurrencyType, double> balances;
  final DateTime createdAt;
  
  Wallet({
    required this.privateKey,
    required this.publicAddresses,
    Map<CryptocurrencyType, double>? balances,
  }) : 
    this.balances = balances ?? {},
    this.createdAt = DateTime.now();
  
  bool get hasBalance {
    return balances.values.any((balance) => balance > 0);
  }
  
  double getTotalBalance() {
    return balances.values.fold(0, (sum, balance) => sum + balance);
  }
  
  Map<String, dynamic> toJson() {
    return {
      'privateKey': privateKey,
      'publicAddresses': publicAddresses.map((key, value) => MapEntry(key.toString(), value)),
      'balances': balances.map((key, value) => MapEntry(key.toString(), value)),
      'createdAt': createdAt.toIso8601String(),
    };
  }
  
  factory Wallet.fromJson(Map<String, dynamic> json) {
    final publicAddressesMap = <CryptocurrencyType, String>{};
    final balancesMap = <CryptocurrencyType, double>{};
    
    (json['publicAddresses'] as Map<String, dynamic>).forEach((key, value) {
      final cryptoType = CryptocurrencyType.values.firstWhere(
        (e) => e.toString() == key,
        orElse: () => CryptocurrencyType.BTC,
      );
      publicAddressesMap[cryptoType] = value;
    });
    
    (json['balances'] as Map<String, dynamic>).forEach((key, value) {
      final cryptoType = CryptocurrencyType.values.firstWhere(
        (e) => e.toString() == key,
        orElse: () => CryptocurrencyType.BTC,
      );
      balancesMap[cryptoType] = value.toDouble();
    });
    
    return Wallet(
      privateKey: json['privateKey'],
      publicAddresses: publicAddressesMap,
      balances: balancesMap,
    );
  }
}
