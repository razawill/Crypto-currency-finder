import 'wallet.dart';

class HitLog {
  final List<Wallet> hits;
  
  HitLog({List<Wallet>? hits}) : hits = hits ?? [];
  
  void addHit(Wallet wallet) {
    if (!hits.any((hit) => hit.privateKey == wallet.privateKey)) {
      hits.add(wallet);
    }
  }
  
  void clear() {
    hits.clear();
  }
  
  List<Map<String, dynamic>> toJson() {
    return hits.map((wallet) => wallet.toJson()).toList();
  }
  
  factory HitLog.fromJson(List<Map<String, dynamic>> json) {
    return HitLog(
      hits: json.map((walletJson) => Wallet.fromJson(walletJson)).toList(),
    );
  }
}

class ScanStats {
  int keysChecked = 0;
  int hitsFound = 0;
  DateTime? startTime;
  DateTime? endTime;
  bool isScanning = false;
  bool isPaused = false;
  
  void reset() {
    keysChecked = 0;
    hitsFound = 0;
    startTime = null;
    endTime = null;
    isScanning = false;
    isPaused = false;
  }
  
  void start() {
    if (!isScanning) {
      startTime = DateTime.now();
      isScanning = true;
      isPaused = false;
    }
  }
  
  void pause() {
    isPaused = true;
  }
  
  void resume() {
    isPaused = false;
  }
  
  void stop() {
    endTime = DateTime.now();
    isScanning = false;
    isPaused = false;
  }
  
  Duration get duration {
    if (startTime == null) {
      return Duration.zero;
    }
    
    if (isScanning) {
      return DateTime.now().difference(startTime!);
    }
    
    if (endTime != null) {
      return endTime!.difference(startTime!);
    }
    
    return Duration.zero;
  }
  
  double get keysPerSecond {
    final seconds = duration.inSeconds;
    if (seconds == 0) return 0;
    return keysChecked / seconds;
  }
}
