# Crypto Wallet Discovery

A Flutter-based Android cryptocurrency wallet discovery app that randomly generates private keys, checks balances across multiple cryptocurrencies, and securely logs addresses with funds.

## Description

This application is designed to randomly generate cryptocurrency wallet private keys and check if they have existing balances. It supports multiple cryptocurrencies including Bitcoin (BTC), Ethereum (ETH), Dogecoin (DOGE), Litecoin (LTC), and Dash (DASH).

**Note:** This app is for educational purposes only. The odds of finding a wallet with a balance are astronomically small, as there are 2^256 possible private keys.

## Features

- Random private key generation using secure cryptography
- Address derivation for multiple cryptocurrencies (BTC, ETH, DOGE, LTC, DASH)
- Balance checking through multiple free APIs (SoChain, Blockchair, Etherscan)
- Secure encrypted storage of discovered wallets
- Real-time scanning statistics and progress tracking
- Export functionality for saving found wallets
- Pause/Resume scanning capability
- Dark/Light theme toggle
- Adjustable balance thresholds for logging hits

## Technical Implementation

The app is built using Flutter and is structured as follows:

### Core Components

1. **Wallet Generator Service**: Creates random private keys and derives addresses
2. **Address Derivation Service**: Converts private keys to public addresses for different blockchains
3. **Balance Checker Service**: Connects to APIs to check address balances
4. **Scanner Service**: Orchestrates the wallet discovery process
5. **Storage Service**: Securely saves wallet information
6. **Connectivity Service**: Monitors network connection status

### User Interface

- Home Screen: Main scanning controls and statistics
- Results Screen: Displays details of discovered wallets
- Log Screen: Shows history of all wallet hits
- Settings Screen: Configure app behavior and thresholds

## Building the App

Please see the `build_apk_instructions.md` file for detailed steps on building the APK for your Android device.

## Dependencies

- Flutter SDK
- Cryptography libraries (bip32, bip39, web3dart)
- HTTP clients for API connections
- Secure storage for sensitive data

## Security Considerations

- All private keys are generated locally on your device
- Connection to APIs is encrypted using HTTPS
- Found wallet information is stored in encrypted format
- No data is shared with external servers except for balance checking

## APIs Used

- SoChain API for BTC, DOGE, LTC balance checking
- Blockchair API for additional blockchain data
- Etherscan API for ETH balance checking

## License

This project is open source and available under the MIT License.

## Disclaimer

This application is for educational and entertainment purposes only. The likelihood of finding a wallet with a balance is extremely remote. The application does not encourage any illegal activities and should be used responsibly.