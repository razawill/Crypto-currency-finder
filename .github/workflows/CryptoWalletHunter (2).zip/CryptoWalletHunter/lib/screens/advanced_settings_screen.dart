import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/scanner_service.dart';
import '../models/wallet.dart';

class AdvancedSettingsScreen extends StatefulWidget {
  const AdvancedSettingsScreen({Key? key}) : super(key: key);

  @override
  _AdvancedSettingsScreenState createState() => _AdvancedSettingsScreenState();
}

class _AdvancedSettingsScreenState extends State<AdvancedSettingsScreen> {
  // Cryptocurrency selection
  final Map<CryptocurrencyType, bool> _selectedCryptos = {};
  
  // Feature toggles
  bool _useMultiThreading = true;
  bool _useBatchProcessing = true;
  bool _useRandomGeneration = true;
  bool _useBrainWallets = true;
  bool _useVanityAddresses = true;
  bool _useTargetedRanges = true;
  bool _useDictionaryAttack = true;
  bool _useWeakPatterns = true;
  bool _autoSaveHits = true;
  bool _stopOnSignificantFind = true;
  bool _useLowDelayMode = false;
  
  // API selection
  bool _useSoChain = true;
  bool _useBlockchair = true;
  bool _useEtherscan = true;
  
  @override
  void initState() {
    super.initState();
    _initializeSettings();
  }
  
  void _initializeSettings() {
    // Initialize crypto selection (all selected by default)
    for (final type in CryptocurrencyType.values) {
      _selectedCryptos[type] = true;
    }
    
    final scannerService = Provider.of<ScannerService>(context, listen: false);
    final settings = scannerService.getAdvancedSettings();
    
    if (settings != null) {
      // Load cryptocurrency selections
      final selectedCryptos = settings['selectedCryptos'] as Map<String, dynamic>?;
      if (selectedCryptos != null) {
        for (final type in CryptocurrencyType.values) {
          final typeName = type.toString().split('.').last;
          _selectedCryptos[type] = selectedCryptos[typeName] ?? true;
        }
      }
      
      // Load feature toggles
      _useMultiThreading = settings['useMultiThreading'] ?? true;
      _useBatchProcessing = settings['useBatchProcessing'] ?? true;
      _useRandomGeneration = settings['useRandomGeneration'] ?? true;
      _useBrainWallets = settings['useBrainWallets'] ?? true;
      _useVanityAddresses = settings['useVanityAddresses'] ?? true;
      _useTargetedRanges = settings['useTargetedRanges'] ?? true;
      _useDictionaryAttack = settings['useDictionaryAttack'] ?? true;
      _useWeakPatterns = settings['useWeakPatterns'] ?? true;
      _autoSaveHits = settings['autoSaveHits'] ?? true;
      _stopOnSignificantFind = settings['stopOnSignificantFind'] ?? true;
      _useLowDelayMode = settings['useLowDelayMode'] ?? false;
      
      // Load API selections
      _useSoChain = settings['useSoChain'] ?? true;
      _useBlockchair = settings['useBlockchair'] ?? true;
      _useEtherscan = settings['useEtherscan'] ?? true;
    }
  }
  
  void _saveSettings() {
    final scannerService = Provider.of<ScannerService>(context, listen: false);
    
    // Create advanced settings map
    final Map<String, dynamic> advancedSettings = {
      'selectedCryptos': _selectedCryptos.map(
        (key, value) => MapEntry(key.toString().split('.').last, value)
      ),
      'useMultiThreading': _useMultiThreading,
      'useBatchProcessing': _useBatchProcessing,
      'useRandomGeneration': _useRandomGeneration,
      'useBrainWallets': _useBrainWallets,
      'useVanityAddresses': _useVanityAddresses,
      'useTargetedRanges': _useTargetedRanges,
      'useDictionaryAttack': _useDictionaryAttack,
      'useWeakPatterns': _useWeakPatterns,
      'autoSaveHits': _autoSaveHits,
      'stopOnSignificantFind': _stopOnSignificantFind,
      'useLowDelayMode': _useLowDelayMode,
      'useSoChain': _useSoChain,
      'useBlockchair': _useBlockchair,
      'useEtherscan': _useEtherscan,
    };
    
    // Save to scanner service
    scannerService.updateAdvancedSettings(advancedSettings);
    
    // Update scan speed if low delay mode is enabled
    if (_useLowDelayMode) {
      scannerService.updateSettings(scanDelay: 10); // Ultra-fast mode
    } else {
      scannerService.updateSettings(scanDelay: 50); // Normal mode
    }
    
    // Update threading
    if (_useMultiThreading) {
      scannerService.updateSettings(numThreads: 2); // Use multiple threads
    } else {
      scannerService.updateSettings(numThreads: 1); // Single thread
    }
    
    // Update batch processing
    if (_useBatchProcessing) {
      scannerService.updateSettings(batchSize: 5); // Process in batches
    } else {
      scannerService.updateSettings(batchSize: 1); // Process one at a time
    }
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Advanced settings saved')),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Advanced Settings'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveSettings,
            tooltip: 'Save Settings',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          // Cryptocurrency Selection
          _buildSectionCard(
            title: 'Cryptocurrencies to Scan',
            child: Column(
              children: [
                const Text(
                  'Select which cryptocurrencies to check for balances:',
                  style: TextStyle(fontSize: 14),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8.0,
                  runSpacing: 8.0,
                  children: CryptocurrencyType.values.map((type) {
                    return FilterChip(
                      label: Text(_getCryptoName(type)),
                      selected: _selectedCryptos[type] ?? true,
                      onSelected: (selected) {
                        setState(() {
                          _selectedCryptos[type] = selected;
                        });
                      },
                      avatar: CircleAvatar(
                        backgroundColor: Colors.transparent,
                        child: Text(
                          _getCryptoSymbol(type).substring(0, 1),
                          style: TextStyle(
                            color: _selectedCryptos[type] ?? true 
                              ? Theme.of(context).colorScheme.onSecondary
                              : Theme.of(context).colorScheme.onSurface,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        setState(() {
                          for (final type in CryptocurrencyType.values) {
                            _selectedCryptos[type] = true;
                          }
                        });
                      },
                      child: const Text('Select All'),
                    ),
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: () {
                        setState(() {
                          for (final type in CryptocurrencyType.values) {
                            _selectedCryptos[type] = false;
                          }
                        });
                      },
                      child: const Text('Clear All'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Scanning Features
          _buildSectionCard(
            title: 'Scanning Features',
            child: Column(
              children: [
                const Text(
                  'Enable or disable specific scanning features:',
                  style: TextStyle(fontSize: 14),
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  title: const Text('Random Generation'),
                  subtitle: const Text('Generate completely random private keys'),
                  value: _useRandomGeneration,
                  onChanged: (value) {
                    setState(() {
                      _useRandomGeneration = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Brain Wallets'),
                  subtitle: const Text('Check common phrases and words'),
                  value: _useBrainWallets,
                  onChanged: (value) {
                    setState(() {
                      _useBrainWallets = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Vanity Addresses'),
                  subtitle: const Text('Target specific address patterns'),
                  value: _useVanityAddresses,
                  onChanged: (value) {
                    setState(() {
                      _useVanityAddresses = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Targeted Ranges'),
                  subtitle: const Text('Focus on more promising key ranges'),
                  value: _useTargetedRanges,
                  onChanged: (value) {
                    setState(() {
                      _useTargetedRanges = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Dictionary Attack'),
                  subtitle: const Text('Check common passwords as brain wallets'),
                  value: _useDictionaryAttack,
                  onChanged: (value) {
                    setState(() {
                      _useDictionaryAttack = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Weak Pattern Detection'),
                  subtitle: const Text('Target poorly generated private keys'),
                  value: _useWeakPatterns,
                  onChanged: (value) {
                    setState(() {
                      _useWeakPatterns = value;
                    });
                  },
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Performance Settings
          _buildSectionCard(
            title: 'Performance Settings',
            child: Column(
              children: [
                const Text(
                  'Configure performance and scanning behavior:',
                  style: TextStyle(fontSize: 14),
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  title: const Text('Multi-threading'),
                  subtitle: const Text('Use multiple threads for faster scanning'),
                  value: _useMultiThreading,
                  onChanged: (value) {
                    setState(() {
                      _useMultiThreading = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Batch Processing'),
                  subtitle: const Text('Process multiple wallets at once'),
                  value: _useBatchProcessing,
                  onChanged: (value) {
                    setState(() {
                      _useBatchProcessing = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Ultra-Fast Mode'),
                  subtitle: const Text('Minimum delay between scans (may cause API errors)'),
                  value: _useLowDelayMode,
                  onChanged: (value) {
                    setState(() {
                      _useLowDelayMode = value;
                    });
                  },
                ),
                if (_useLowDelayMode)
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.0),
                    child: Text(
                      'Warning: Ultra-fast mode may cause API rate limit errors!',
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
              ],
            ),
          ),
          
          const SizedBox(height: 16),
          
          // API Selection
          _buildSectionCard(
            title: 'API Selection',
            child: Column(
              children: [
                const Text(
                  'Choose which APIs to use for balance checking:',
                  style: TextStyle(fontSize: 14),
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  title: const Text('SoChain API'),
                  subtitle: const Text('For BTC, LTC, DOGE'),
                  value: _useSoChain,
                  onChanged: (value) {
                    setState(() {
                      _useSoChain = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Blockchair API'),
                  subtitle: const Text('For BTC, ETH, DASH, LTC, DOGE'),
                  value: _useBlockchair,
                  onChanged: (value) {
                    setState(() {
                      _useBlockchair = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Etherscan API'),
                  subtitle: const Text('For ETH only'),
                  value: _useEtherscan,
                  onChanged: (value) {
                    setState(() {
                      _useEtherscan = value;
                    });
                  },
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Behavior Settings
          _buildSectionCard(
            title: 'Behavior Settings',
            child: Column(
              children: [
                const Text(
                  'Configure app behavior:',
                  style: TextStyle(fontSize: 14),
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  title: const Text('Auto-Save Hits'),
                  subtitle: const Text('Automatically save wallets with balances'),
                  value: _autoSaveHits,
                  onChanged: (value) {
                    setState(() {
                      _autoSaveHits = value;
                    });
                  },
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Stop on Significant Find'),
                  subtitle: const Text('Stop scanning when finding valuable wallet'),
                  value: _stopOnSignificantFind,
                  onChanged: (value) {
                    setState(() {
                      _stopOnSignificantFind = value;
                    });
                  },
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          ElevatedButton(
            onPressed: () {
              _saveSettings();
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
            child: const Text('Save and Return'),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSectionCard({required String title, required Widget child}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            child,
          ],
        ),
      ),
    );
  }
  
  String _getCryptoName(CryptocurrencyType type) {
    switch (type) {
      case CryptocurrencyType.BTC:
        return 'Bitcoin';
      case CryptocurrencyType.ETH:
        return 'Ethereum';
      case CryptocurrencyType.DOGE:
        return 'Dogecoin';
      case CryptocurrencyType.LTC:
        return 'Litecoin';
      case CryptocurrencyType.DASH:
        return 'Dash';
      case CryptocurrencyType.SOL:
        return 'Solana';
    }
    return 'Unknown'; // Default fallback
  }
  
  String _getCryptoSymbol(CryptocurrencyType type) {
    switch (type) {
      case CryptocurrencyType.BTC:
        return 'BTC';
      case CryptocurrencyType.ETH:
        return 'ETH';
      case CryptocurrencyType.DOGE:
        return 'DOGE';
      case CryptocurrencyType.LTC:
        return 'LTC';
      case CryptocurrencyType.DASH:
        return 'DASH';
      case CryptocurrencyType.SOL:
        return 'SOL';
    }
    return 'Unknown'; // Default fallback
  }
}