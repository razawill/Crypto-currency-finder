import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/scanner_service.dart';
import '../services/wallet_scanning_strategy.dart';
import '../models/wallet.dart';
import '../theme/theme_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _backgroundMode = false;
  int _scanDelay = 50;
  int _apiRateLimit = 10;
  int _numThreads = 2;
  int _batchSize = 5;
  bool _useBrainWallet = false;
  String _brainWalletPhrase = '';
  final _brainWalletController = TextEditingController();
  ScanningStrategy _scanningStrategy = ScanningStrategy.mixed;
  
  final Map<CryptocurrencyType, double> _balanceThresholds = {};
  final Map<CryptocurrencyType, TextEditingController> _thresholdControllers = {};

  @override
  void initState() {
    super.initState();
    _loadSettings();
    
    // Initialize threshold controllers for each crypto type
    for (final cryptoType in CryptocurrencyType.values) {
      _thresholdControllers[cryptoType] = TextEditingController();
    }
  }

  @override
  void dispose() {
    _brainWalletController.dispose();
    for (final controller in _thresholdControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  // Load current settings from scanner service
  void _loadSettings() {
    final scannerService = Provider.of<ScannerService>(context, listen: false);
    
    setState(() {
      _backgroundMode = scannerService.backgroundMode;
      _useBrainWallet = scannerService.useBrainWallet;
      _brainWalletPhrase = scannerService.brainWalletPhrase;
      _brainWalletController.text = _brainWalletPhrase;
      _scanningStrategy = scannerService.scanningStrategy;
      
      // Load balance thresholds from scanner service
      for (final type in CryptocurrencyType.values) {
        // Default threshold is 0.000001 (1 satoshi for BTC, or equivalent for other coins)
        final threshold = scannerService.hitLog.getThreshold(type) ?? 0.000001;
        _balanceThresholds[type] = threshold;
        _thresholdControllers[type]?.text = threshold.toStringAsFixed(8);
      }
    });
  }

  // Save settings to scanner service
  void _saveSettings() {
    final scannerService = Provider.of<ScannerService>(context, listen: false);
    
    scannerService.updateSettings(
      backgroundMode: _backgroundMode,
      scanDelay: _scanDelay,
      apiRateLimit: _apiRateLimit,
      numThreads: _numThreads,
      batchSize: _batchSize,
      scanningStrategy: _scanningStrategy,
      useBrainWallet: _useBrainWallet,
      brainWalletPhrase: _brainWalletPhrase,
      thresholds: _balanceThresholds,
    );
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Settings saved')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        actions: [
          IconButton(
            icon: Icon(themeProvider.themeMode == ThemeMode.dark 
              ? Icons.light_mode 
              : Icons.dark_mode),
            onPressed: () {
              themeProvider.toggleTheme();
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          // Scanning Strategy Section
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Scanning Strategy',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Choose a strategy to increase your chances of finding wallets with balances:',
                    style: TextStyle(fontSize: 14),
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<ScanningStrategy>(
                    value: _scanningStrategy,
                    onChanged: (value) {
                      if (value != null) {
                        setState(() {
                          _scanningStrategy = value;
                        });
                      }
                    },
                    items: ScanningStrategy.values.map((strategy) {
                      return DropdownMenuItem<ScanningStrategy>(
                        value: strategy,
                        child: Text(_getStrategyDisplayName(strategy)),
                      );
                    }).toList(),
                    decoration: const InputDecoration(
                      labelText: 'Strategy',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _getStrategyDescription(_scanningStrategy),
                    style: const TextStyle(
                      fontSize: 14,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Brain Wallet Section
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Brain Wallet',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    title: const Text('Use Brain Wallet'),
                    subtitle: const Text('Generate keys from phrases/words'),
                    value: _useBrainWallet,
                    onChanged: (value) {
                      setState(() {
                        _useBrainWallet = value;
                      });
                    },
                  ),
                  if (_useBrainWallet) ...[
                    const SizedBox(height: 8),
                    TextField(
                      controller: _brainWalletController,
                      decoration: const InputDecoration(
                        labelText: 'Brain Wallet Phrase (optional)',
                        hintText: 'Enter a phrase to use as seed',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (value) {
                        _brainWalletPhrase = value;
                      },
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'If left empty, common phrases will be used',
                      style: TextStyle(
                        fontSize: 12,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Performance Settings
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Performance Settings',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Slider(
                    value: _scanDelay.toDouble(),
                    min: 0,
                    max: 500,
                    divisions: 50,
                    label: '${_scanDelay}ms',
                    onChanged: (value) {
                      setState(() {
                        _scanDelay = value.round();
                      });
                    },
                  ),
                  Text('Scan Delay: ${_scanDelay}ms'),
                  const SizedBox(height: 16),
                  
                  Slider(
                    value: _numThreads.toDouble(),
                    min: 1,
                    max: 4,
                    divisions: 3,
                    label: '$_numThreads threads',
                    onChanged: (value) {
                      setState(() {
                        _numThreads = value.round();
                      });
                    },
                  ),
                  Text('Number of Threads: $_numThreads'),
                  const SizedBox(height: 16),
                  
                  Slider(
                    value: _batchSize.toDouble(),
                    min: 1,
                    max: 20,
                    divisions: 19,
                    label: '$_batchSize wallets',
                    onChanged: (value) {
                      setState(() {
                        _batchSize = value.round();
                      });
                    },
                  ),
                  Text('Batch Size: $_batchSize wallets'),
                  const SizedBox(height: 16),
                  
                  SwitchListTile(
                    title: const Text('Background Mode'),
                    subtitle: const Text('Continue scanning when app is in background'),
                    value: _backgroundMode,
                    onChanged: (value) {
                      setState(() {
                        _backgroundMode = value;
                      });
                    },
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Balance Thresholds
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Balance Thresholds',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Minimum balance to log a hit (in the cryptocurrency unit):',
                    style: TextStyle(fontSize: 14),
                  ),
                  const SizedBox(height: 16),
                  ...CryptocurrencyType.values.map((type) => Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 80,
                          child: Text(_getCryptoName(type)),
                        ),
                        Expanded(
                          child: TextField(
                            controller: _thresholdControllers[type],
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: InputDecoration(
                              border: const OutlineInputBorder(),
                              hintText: '0.00000001',
                              suffixText: _getCryptoSymbol(type),
                            ),
                            onChanged: (value) {
                              try {
                                final threshold = double.parse(value);
                                setState(() {
                                  _balanceThresholds[type] = threshold;
                                });
                              } catch (e) {
                                // Invalid number, ignore
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  )).toList(),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          ElevatedButton(
            onPressed: _saveSettings,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
            child: const Text('Save Settings'),
          ),
          
          const SizedBox(height: 16),
          
          OutlinedButton.icon(
            onPressed: () {
              Navigator.pushNamed(context, '/advanced_settings');
            },
            icon: const Icon(Icons.tune),
            label: const Text('Advanced Settings'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
            ),
          ),
          
          const SizedBox(height: 16),
          
          OutlinedButton.icon(
            onPressed: () {
              Navigator.pushNamed(context, '/brain_wallet');
            },
            icon: const Icon(Icons.psychology),
            label: const Text('Brain Wallet Tools'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
            ),
          ),
        ],
      ),
    );
  }
  
  // Helper methods to get readable names for enums
  String _getStrategyDisplayName(ScanningStrategy strategy) {
    switch (strategy) {
      case ScanningStrategy.random:
        return 'Random (Pure Random Generation)';
      case ScanningStrategy.brainWallet:
        return 'Brain Wallet (Common Phrases)';
      case ScanningStrategy.vanityAddress:
        return 'Vanity Addresses (Pattern Matching)';
      case ScanningStrategy.targetedRange:
        return 'Targeted Ranges (Likely Key Ranges)';
      case ScanningStrategy.dictionaryAttack:
        return 'Dictionary Attack (Common Passwords)';
      case ScanningStrategy.weakPatterns:
        return 'Weak Patterns (Poor Randomness)';
      case ScanningStrategy.hdWalletDerivation:
        return 'HD Wallet Derivation (Path Scanning)';
      case ScanningStrategy.mixed:
        return 'Mixed Strategy (Combined Approach)';
    }
  }
  
  String _getStrategyDescription(ScanningStrategy strategy) {
    switch (strategy) {
      case ScanningStrategy.random:
        return 'Generates completely random private keys using secure cryptography.';
      case ScanningStrategy.brainWallet:
        return 'Creates private keys from common phrases, words, and passphrases that people might use.';
      case ScanningStrategy.vanityAddress:
        return 'Focuses on addresses with specific patterns that might be more likely to contain funds.';
      case ScanningStrategy.targetedRange:
        return 'Targets specific ranges of private keys that are more likely to have been used.';
      case ScanningStrategy.dictionaryAttack:
        return 'Uses a list of common passwords and phrases that people might have used as brain wallets.';
      case ScanningStrategy.weakPatterns:
        return 'Looks for wallets generated with weak randomness patterns or predictable methods.';
      case ScanningStrategy.hdWalletDerivation:
        return 'Derives keys using standard hierarchical deterministic wallet paths from seed phrases.';
      case ScanningStrategy.mixed:
        return 'Combines all strategies, switching between them periodically for best results.';
    }
  }
  
  String _getCryptoName(CryptocurrencyType type) {
    switch (type) {
      case CryptocurrencyType.BTC:
        return 'Bitcoin';
      case CryptocurrencyType.ETH:
        return 'Ethereum';
      case CryptocurrencyType.DOGE:
        return 'Dogecoin';
      case CryptocurrencyType.LTC:
        return 'Litecoin';
      case CryptocurrencyType.DASH:
        return 'Dash';
      case CryptocurrencyType.SOL:
        return 'Solana';
    }
    return 'Unknown'; // Default fallback
  }
  
  String _getCryptoSymbol(CryptocurrencyType type) {
    switch (type) {
      case CryptocurrencyType.BTC:
        return 'BTC';
      case CryptocurrencyType.ETH:
        return 'ETH';
      case CryptocurrencyType.DOGE:
        return 'DOGE';
      case CryptocurrencyType.LTC:
        return 'LTC';
      case CryptocurrencyType.DASH:
        return 'DASH';
      case CryptocurrencyType.SOL:
        return 'SOL';
    }
    return 'Unknown'; // Default fallback
  }
}