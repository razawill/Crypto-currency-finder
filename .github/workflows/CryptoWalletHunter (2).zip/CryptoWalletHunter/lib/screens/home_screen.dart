import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/scanner_service.dart';
import '../services/storage_service.dart';
import '../services/connectivity_service.dart';
import '../widgets/wallet_card.dart';
import '../widgets/scan_controls.dart';
import '../widgets/progress_display.dart';
import '../widgets/connectivity_banner.dart';
import '../theme/theme_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late ScannerService _scannerService;
  
  @override
  void initState() {
    super.initState();
    final storageService = Provider.of<StorageService>(context, listen: false);
    _scannerService = ScannerService(storageService);
    
    // Listen for wallet found events
    _scannerService.walletFoundStream.listen((wallet) {
      showWalletFoundDialog(wallet);
    });
  }
  
  void showWalletFoundDialog(wallet) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text('Wallet Found!'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('A wallet with balance has been found!', style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 16),
              Text('Private Key:', style: TextStyle(fontWeight: FontWeight.bold)),
              SelectableText(wallet.privateKey, style: TextStyle(fontSize: 12)),
              SizedBox(height: 16),
              Text('Addresses:', style: TextStyle(fontWeight: FontWeight.bold)),
              for (final entry in wallet.publicAddresses.entries)
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${entry.key}:', style: TextStyle(fontWeight: FontWeight.w500)),
                      SelectableText(entry.value, style: TextStyle(fontSize: 12)),
                    ],
                  ),
                ),
              SizedBox(height: 16),
              Text('Balances:', style: TextStyle(fontWeight: FontWeight.bold)),
              for (final entry in wallet.balances.entries)
                if (entry.value > 0)
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Text('${entry.key}: ${entry.value}', 
                      style: TextStyle(color: Colors.green, fontWeight: FontWeight.w500)),
                  ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushNamed(context, '/result', arguments: wallet);
            },
            child: Text('View Details'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    final connectivityService = Provider.of<ConnectivityService>(context);
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return ChangeNotifierProvider.value(
      value: _scannerService,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Crypto Wallet Discovery'),
          actions: [
            IconButton(
              icon: Icon(themeProvider.themeMode == ThemeMode.dark ? Icons.light_mode : Icons.dark_mode),
              onPressed: () {
                themeProvider.toggleTheme();
              },
            ),
            IconButton(
              icon: const Icon(Icons.settings),
              onPressed: () {
                Navigator.pushNamed(context, '/settings');
              },
            ),
          ],
        ),
        body: !connectivityService.hasConnection
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.wifi_off, size: 80, color: Colors.grey),
                  SizedBox(height: 16),
                  Text(
                    'No Internet Connection',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'This app requires internet access to scan for wallets.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () {
                      connectivityService.checkConnectivity();
                    },
                    child: Text('Retry'),
                  ),
                ],
              ),
            )
          : Consumer<ScannerService>(
              builder: (context, scannerService, child) {
                return Column(
                  children: [
                    if (!connectivityService.hasConnection)
                      ConnectivityBanner(),
                    
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Card(
                              margin: const EdgeInsets.only(bottom: 16),
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Wallet Scanner',
                                      style: Theme.of(context).textTheme.headlineSmall,
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      'This app discovers crypto wallets by generating keys using multiple strategies and checking if they have any balance across multiple cryptocurrencies.',
                                      style: Theme.of(context).textTheme.bodyMedium,
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      'Advanced features include brain wallets, vanity addresses, targeted range scanning, and more.',
                                      style: Theme.of(context).textTheme.bodyMedium,
                                    ),
                                    const SizedBox(height: 16),
                                    ProgressDisplay(),
                                  ],
                                ),
                              ),
                            ),
                            
                            // Controls for scanning
                            ScanControls(),
                            
                            // Quick access to advanced features
                            Card(
                              margin: const EdgeInsets.only(top: 16),
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Advanced Features',
                                      style: Theme.of(context).textTheme.titleLarge,
                                    ),
                                    const SizedBox(height: 16),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Column(
                                          children: [
                                            IconButton(
                                              icon: const Icon(Icons.psychology),
                                              onPressed: () {
                                                Navigator.pushNamed(context, '/brain_wallet');
                                              },
                                              tooltip: 'Brain Wallet',
                                              iconSize: 32,
                                            ),
                                            const Text('Brain Wallet'),
                                          ],
                                        ),
                                        Column(
                                          children: [
                                            IconButton(
                                              icon: const Icon(Icons.tune),
                                              onPressed: () {
                                                Navigator.pushNamed(context, '/advanced_settings');
                                              },
                                              tooltip: 'Advanced Settings',
                                              iconSize: 32,
                                            ),
                                            const Text('Advanced'),
                                          ],
                                        ),
                                        Column(
                                          children: [
                                            IconButton(
                                              icon: const Icon(Icons.settings),
                                              onPressed: () {
                                                Navigator.pushNamed(context, '/settings');
                                              },
                                              tooltip: 'Settings',
                                              iconSize: 32,
                                            ),
                                            const Text('Settings'),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            
                            // Last wallet found (if any)
                            if (scannerService.lastFoundWallet != null)
                              Padding(
                                padding: const EdgeInsets.only(top: 16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Last Wallet Found',
                                      style: Theme.of(context).textTheme.titleLarge,
                                    ),
                                    const SizedBox(height: 8),
                                    WalletCard(wallet: scannerService.lastFoundWallet!),
                                    const SizedBox(height: 16),
                                    Center(
                                      child: ElevatedButton(
                                        onPressed: () {
                                          Navigator.pushNamed(
                                            context, 
                                            '/result',
                                            arguments: scannerService.lastFoundWallet,
                                          );
                                        },
                                        child: Text('View Full Details'),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            
                            // Hit log summary
                            Padding(
                              padding: const EdgeInsets.only(top: 16),
                              child: Card(
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Wallet Hits',
                                        style: Theme.of(context).textTheme.titleLarge,
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        'Total hits found: ${scannerService.hitLog.hits.length}',
                                        style: Theme.of(context).textTheme.bodyLarge,
                                      ),
                                      const SizedBox(height: 16),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          ElevatedButton.icon(
                                            icon: const Icon(Icons.list),
                                            label: const Text('View All Hits'),
                                            onPressed: scannerService.hitLog.hits.isEmpty
                                                ? null
                                                : () {
                                                    Navigator.pushNamed(context, '/logs');
                                                  },
                                          ),
                                          ElevatedButton.icon(
                                            icon: const Icon(Icons.file_download),
                                            label: const Text('Export Hits'),
                                            onPressed: scannerService.hitLog.hits.isEmpty
                                                ? null
                                                : () async {
                                                    final path = await scannerService.exportHits();
                                                    if (path != null) {
                                                      ScaffoldMessenger.of(context).showSnackBar(
                                                        SnackBar(
                                                          content: Text('Exported to: $path'),
                                                          backgroundColor: Colors.green,
                                                        ),
                                                      );
                                                    } else {
                                                      ScaffoldMessenger.of(context).showSnackBar(
                                                        const SnackBar(
                                                          content: Text('Failed to export hit log'),
                                                          backgroundColor: Colors.red,
                                                        ),
                                                      );
                                                    }
                                                  },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
      ),
    );
  }
  
  @override
  void dispose() {
    _scannerService.dispose();
    super.dispose();
  }
}
