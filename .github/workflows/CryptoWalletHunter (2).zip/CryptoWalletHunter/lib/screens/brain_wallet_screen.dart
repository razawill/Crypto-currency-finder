import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/scanner_service.dart';
import '../services/brain_wallet_service.dart';
import '../models/wallet.dart';
import '../widgets/wallet_card.dart';

class BrainWalletScreen extends StatefulWidget {
  const BrainWalletScreen({Key? key}) : super(key: key);

  @override
  _BrainWalletScreenState createState() => _BrainWalletScreenState();
}

class _BrainWalletScreenState extends State<BrainWalletScreen> {
  final _phraseController = TextEditingController();
  final _brainWalletService = BrainWalletService();
  bool _isGenerating = false;
  Wallet? _generatedWallet;
  String _errorMessage = '';
  
  List<String> _commonPhrases = [];
  bool _isLoadingPhrases = true;

  @override
  void initState() {
    super.initState();
    _loadCommonPhrases();
  }

  void _loadCommonPhrases() {
    setState(() {
      _isLoadingPhrases = true;
    });
    
    // Load common phrases from the service
    _commonPhrases = _brainWalletService.generateCommonPhrases();
    _commonPhrases.sort(); // Sort alphabetically
    
    setState(() {
      _isLoadingPhrases = false;
    });
  }

  @override
  void dispose() {
    _phraseController.dispose();
    super.dispose();
  }

  // Generate a wallet from the entered phrase
  Future<void> _generateWallet() async {
    final phrase = _phraseController.text.trim();
    
    if (phrase.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter a phrase';
      });
      return;
    }
    
    setState(() {
      _isGenerating = true;
      _errorMessage = '';
      _generatedWallet = null;
    });
    
    try {
      final scannerService = Provider.of<ScannerService>(context, listen: false);
      final wallet = await scannerService.generateBrainWallet(phrase);
      
      // Check balance immediately
      final balances = await scannerService.startWalletBalanceCheck(wallet);
      
      setState(() {
        _generatedWallet = Wallet(
          privateKey: wallet.privateKey,
          publicAddresses: wallet.publicAddresses,
          balances: balances,
        );
        _isGenerating = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Error generating wallet: ${e.toString()}';
        _isGenerating = false;
      });
    }
  }
  
  // Run a dictionary attack on common phrases
  Future<void> _runDictionaryAttack() async {
    try {
      setState(() {
        _isGenerating = true;
        _errorMessage = '';
      });
      
      final scannerService = Provider.of<ScannerService>(context, listen: false);
      await scannerService.runDictionaryAttack(limit: 50);
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dictionary attack started, check Logs for results')),
      );
      
      // Navigate to log screen
      Navigator.pushNamed(context, '/logs');
      
    } catch (e) {
      setState(() {
        _errorMessage = 'Error starting dictionary attack: ${e.toString()}';
      });
    } finally {
      setState(() {
        _isGenerating = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Brain Wallet Scanner'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Brain Wallet Generator',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'A brain wallet is created from a passphrase. '
                      'The same passphrase will always generate the same wallet address. '
                      'This makes it vulnerable if you use a common phrase.',
                      style: TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _phraseController,
                      decoration: const InputDecoration(
                        labelText: 'Enter Passphrase',
                        hintText: 'Example: correct horse battery staple',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        ElevatedButton(
                          onPressed: _isGenerating ? null : _generateWallet,
                          child: _isGenerating
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Text('Generate Wallet'),
                        ),
                        OutlinedButton(
                          onPressed: _isGenerating ? null : () {
                            // Choose a random phrase from the list
                            if (_commonPhrases.isNotEmpty) {
                              final randomIndex = DateTime.now().millisecondsSinceEpoch % _commonPhrases.length;
                              _phraseController.text = _commonPhrases[randomIndex];
                            }
                          },
                          child: const Text('Try Random Phrase'),
                        ),
                      ],
                    ),
                    if (_errorMessage.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 16.0),
                        child: Text(
                          _errorMessage,
                          style: const TextStyle(color: Colors.red),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Generated wallet result
            if (_generatedWallet != null)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Generated Wallet',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      WalletCard(wallet: _generatedWallet!),
                    ],
                  ),
                ),
              ),
            
            const SizedBox(height: 16),
            
            // Dictionary attack section
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Dictionary Attack',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Scan multiple common phrases and passphrases that people might use '
                      'as brain wallets. This will check balances for each generated address.',
                      style: TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _isGenerating ? null : _runDictionaryAttack,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Theme.of(context).colorScheme.secondary,
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      child: _isGenerating
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text('Start Dictionary Attack'),
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Common phrases
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Common Brain Wallet Phrases',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'These are examples of phrases people might use to create brain wallets. '
                      'Because they are common, they are vulnerable to attacks.',
                      style: TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 16),
                    _isLoadingPhrases
                        ? const Center(child: CircularProgressIndicator())
                        : Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _commonPhrases
                                .take(20) // Show only first 20 for UI clarity
                                .map((phrase) => ActionChip(
                                      label: Text(phrase),
                                      onPressed: () {
                                        _phraseController.text = phrase;
                                      },
                                    ))
                                .toList(),
                          ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}