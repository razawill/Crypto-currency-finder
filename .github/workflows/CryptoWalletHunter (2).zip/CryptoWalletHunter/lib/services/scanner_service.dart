import 'dart:async';
import 'dart:isolate';
import 'package:flutter/foundation.dart';
import '../models/wallet.dart';
import '../models/hit_log.dart';
import 'wallet_generator.dart';
import 'balance_checker.dart';
import 'storage_service.dart';
import 'brain_wallet_service.dart';
import 'vanity_address_service.dart';
import 'targeted_range_service.dart';
import 'wallet_scanning_strategy.dart';

class ScannerService extends ChangeNotifier {
  final WalletGenerator _walletGenerator = WalletGenerator();
  final BalanceCheckerService _balanceChecker = BalanceCheckerService();
  final StorageService _storageService;
  final BrainWalletService _brainWalletService = BrainWalletService();
  final VanityAddressService _vanityAddressService = VanityAddressService();
  final TargetedRangeService _targetedRangeService = TargetedRangeService();
  late WalletScanningStrategyService _scanningStrategyService;
  
  final HitLog _hitLog = HitLog();
  final ScanStats _stats = ScanStats();
  
  Timer? _progressUpdateTimer;
  List<Isolate> _scanningIsolates = [];
  final List<ReceivePort> _receivePorts = [];
  
  // Thresholds for recording hits
  Map<CryptocurrencyType, double> _balanceThresholds = {};
  
  // Configuration
  bool _backgroundMode = false;
  int _numThreads = 2; // Default to 2 threads to improve performance
  int _scanDelay = 50; // Reduced delay for faster scanning
  int _apiRateLimit = 10; // Increased rate limit
  int _batchSize = 5; // Process wallets in batches for efficiency
  
  // Selected scanning strategy
  ScanningStrategy _scanningStrategy = ScanningStrategy.mixed;
  
  // Brain wallet options
  String _brainWalletPhrase = '';
  bool _useBrainWallet = false;
  
  bool get isScanning => _stats.isScanning;
  bool get isPaused => _stats.isPaused;
  ScanStats get stats => _stats;
  HitLog get hitLog => _hitLog;
  
  bool get backgroundMode => _backgroundMode;
  bool get useBrainWallet => _useBrainWallet;
  String get brainWalletPhrase => _brainWalletPhrase;
  ScanningStrategy get scanningStrategy => _scanningStrategy;
  
  Wallet? _lastFoundWallet;
  Wallet? get lastFoundWallet => _lastFoundWallet;
  
  StreamController<Wallet> _walletFoundController = StreamController<Wallet>.broadcast();
  Stream<Wallet> get walletFoundStream => _walletFoundController.stream;
  
  ScannerService(this._storageService) {
    _scanningStrategyService = WalletScanningStrategyService();
    _loadSettings();
    _loadHitLog();
    _initializeStrategies();
  }
  
  // Initialize scanning strategies
  Future<void> _initializeStrategies() async {
    await _scanningStrategyService.initialize();
  }
  
  // Load settings from storage
  Future<void> _loadSettings() async {
    final settings = await _storageService.loadSettings();
    
    _backgroundMode = settings['backgroundScan'] ?? false;
    _scanDelay = settings['scanDelay'] ?? 50;
    _apiRateLimit = settings['apiRateLimit'] ?? 10;
    _numThreads = settings['numThreads'] ?? 2;
    _batchSize = settings['batchSize'] ?? 5;
    _useBrainWallet = settings['useBrainWallet'] ?? false;
    _brainWalletPhrase = settings['brainWalletPhrase'] ?? '';
    
    // Load scanning strategy
    final strategyString = settings['scanningStrategy'] as String?;
    if (strategyString != null) {
      try {
        _scanningStrategy = ScanningStrategy.values.firstWhere(
          (strategy) => strategy.toString() == 'ScanningStrategy.$strategyString'
        );
      } catch (e) {
        _scanningStrategy = ScanningStrategy.mixed;
      }
    }
    
    // Load balance thresholds
    final thresholds = settings['balanceThresholds'];
    if (thresholds != null) {
      _balanceThresholds = {};
      for (final entry in thresholds.entries) {
        final type = _cryptoTypeFromString(entry.key);
        if (type != null) {
          _balanceThresholds[type] = entry.value.toDouble();
        }
      }
    }
  }
  
  // Convert string to CryptocurrencyType
  CryptocurrencyType? _cryptoTypeFromString(String value) {
    return CryptocurrencyType.values.firstWhere(
      (type) => type.toString() == 'CryptocurrencyType.$value',
      orElse: () => CryptocurrencyType.BTC,
    );
  }
  
  // Load hit log from storage
  Future<void> _loadHitLog() async {
    final savedHitLog = await _storageService.loadHitLog();
    _hitLog.hits.addAll(savedHitLog.hits);
    notifyListeners();
  }
  
  // Start wallet scanning
  Future<void> startScanning() async {
    if (_stats.isScanning && !_stats.isPaused) {
      return;
    }
    
    if (_stats.isPaused) {
      _stats.resume();
      notifyListeners();
      return;
    }
    
    _stats.reset();
    _stats.start();
    _lastFoundWallet = null;
    
    // Initialize the scanning strategy
    _scanningStrategyService.setStrategy(_scanningStrategy);
    if (_useBrainWallet && _brainWalletPhrase.isNotEmpty) {
      _scanningStrategyService.setBrainWalletPhrase(_brainWalletPhrase);
    }
    
    // Start periodic update of UI
    _progressUpdateTimer = Timer.periodic(const Duration(milliseconds: 250), (_) {
      notifyListeners();
    });
    
    if (_numThreads > 1) {
      await _startMultiThreadedScanning();
    } else {
      _startSingleThreadedScanning();
    }
    
    notifyListeners();
  }
  
  // Start scanning with a single thread
  void _startSingleThreadedScanning() {
    if (_batchSize > 1) {
      _batchScanWallets();
    } else {
      _scanWallets();
    }
  }
  
  // Start scanning with multiple threads using isolates
  Future<void> _startMultiThreadedScanning() async {
    // Clean up any existing isolates
    _stopIsolates();
    
    for (int i = 0; i < _numThreads; i++) {
      final receivePort = ReceivePort();
      _receivePorts.add(receivePort);
      
      receivePort.listen((dynamic message) {
        if (message is Map<String, dynamic>) {
          if (message.containsKey('keysChecked')) {
            _stats.keysChecked += message['keysChecked'] as int;
          } else if (message.containsKey('walletFound')) {
            final walletJson = message['walletFound'] as Map<String, dynamic>;
            final wallet = Wallet.fromJson(walletJson);
            _processFoundWallet(wallet);
          }
        }
      });
      
      // Start isolate with configuration
      final isolate = await Isolate.spawn(
        _isolateScanner,
        {
          'sendPort': receivePort.sendPort,
          'config': {
            'scanDelay': _scanDelay,
            'apiRateLimit': _apiRateLimit,
            'thresholds': _balanceThresholds.map((k, v) => MapEntry(k.toString().split('.').last, v)),
            'scanningStrategy': _scanningStrategy.toString().split('.').last,
            'useBrainWallet': _useBrainWallet,
            'brainWalletPhrase': _brainWalletPhrase,
            'batchSize': _batchSize,
          },
        },
      );
      
      _scanningIsolates.add(isolate);
    }
  }
  
  // Isolate entry point for parallel scanning
  static Future<void> _isolateScanner(Map<String, dynamic> params) async {
    final SendPort sendPort = params['sendPort'] as SendPort;
    final Map<String, dynamic> config = params['config'] as Map<String, dynamic>;
    
    // Create services in isolate
    final walletGenerator = WalletGenerator();
    final balanceChecker = BalanceCheckerService();
    final brainWalletService = BrainWalletService();
    final scanningStrategyService = WalletScanningStrategyService();
    
    // Initialize strategy
    await scanningStrategyService.initialize();
    
    // Set strategy
    final strategyString = config['scanningStrategy'] as String?;
    ScanningStrategy strategy = ScanningStrategy.mixed;
    if (strategyString != null) {
      try {
        strategy = ScanningStrategy.values.firstWhere(
          (s) => s.toString().split('.').last == strategyString
        );
      } catch (e) {
        strategy = ScanningStrategy.mixed;
      }
    }
    scanningStrategyService.setStrategy(strategy);
    
    // Set brain wallet phrase if provided
    final useBrainWallet = config['useBrainWallet'] as bool? ?? false;
    final brainWalletPhrase = config['brainWalletPhrase'] as String? ?? '';
    if (useBrainWallet && brainWalletPhrase.isNotEmpty) {
      scanningStrategyService.setBrainWalletPhrase(brainWalletPhrase);
    }
    
    final int scanDelay = config['scanDelay'] ?? 50;
    final int batchSize = config['batchSize'] ?? 5;
    final Map<String, double> thresholds = 
        (config['thresholds'] as Map<String, dynamic>?)?.cast<String, double>() ?? {};
    
    // Process in batches or individually
    if (batchSize > 1) {
      while (true) {
        // Generate batch of wallets
        final wallets = await scanningStrategyService.batchProcessWallets(batchSize);
        
        // Check all wallets in batch
        for (final wallet in wallets) {
          final balances = await balanceChecker.checkAllBalances(wallet);
          
          // Update wallet with balances
          final walletWithBalances = Wallet(
            privateKey: wallet.privateKey,
            publicAddresses: wallet.publicAddresses,
            balances: balances,
          );
          
          // Check if wallet has balance above threshold
          bool hasBalance = false;
          for (final entry in balances.entries) {
            final cryptoName = entry.key.toString().split('.').last;
            final threshold = thresholds[cryptoName] ?? 0.000001;
            if (entry.value > threshold) {
              hasBalance = true;
              break;
            }
          }
          
          if (hasBalance) {
            sendPort.send({'walletFound': walletWithBalances.toJson()});
          }
        }
        
        // Report number of keys checked
        sendPort.send({'keysChecked': batchSize});
        
        // Add delay to avoid overwhelming APIs
        await Future.delayed(Duration(milliseconds: scanDelay));
      }
    } else {
      // Individual wallet processing
      while (true) {
        // Get next wallet using strategy
        final wallet = await scanningStrategyService.getNextWallet();
        
        // Check balances
        final balances = await balanceChecker.checkAllBalances(wallet);
        
        // Update wallet with balances
        final walletWithBalances = Wallet(
          privateKey: wallet.privateKey,
          publicAddresses: wallet.publicAddresses,
          balances: balances,
        );
        
        // Check if wallet has balance above threshold
        bool hasBalance = false;
        for (final entry in balances.entries) {
          final cryptoName = entry.key.toString().split('.').last;
          final threshold = thresholds[cryptoName] ?? 0.000001;
          if (entry.value > threshold) {
            hasBalance = true;
            break;
          }
        }
        
        if (hasBalance) {
          sendPort.send({'walletFound': walletWithBalances.toJson()});
        }
        
        // Report a key checked
        sendPort.send({'keysChecked': 1});
        
        // Add delay to avoid overwhelming APIs
        await Future.delayed(Duration(milliseconds: scanDelay));
      }
    }
  }
  
  // Batch scan wallets for efficiency
  Future<void> _batchScanWallets() async {
    while (_stats.isScanning && !_stats.isPaused) {
      // Generate a batch of wallets based on selected strategy
      final wallets = await _scanningStrategyService.batchProcessWallets(_batchSize);
      
      // Check all wallets in the batch
      for (final wallet in wallets) {
        if (!_stats.isScanning || _stats.isPaused) {
          break;
        }
        
        // Check balances
        final balances = await _balanceChecker.checkAllBalances(wallet);
        
        // Update wallet with balances
        final walletWithBalances = Wallet(
          privateKey: wallet.privateKey,
          publicAddresses: wallet.publicAddresses,
          balances: balances,
        );
        
        // Process the wallet
        _processWallet(walletWithBalances);
        
        // Increment counter
        _stats.keysChecked++;
      }
      
      // Add delay to avoid overwhelming APIs
      await Future.delayed(Duration(milliseconds: _scanDelay));
    }
  }
  
  // Main scanning loop for single wallets
  Future<void> _scanWallets() async {
    while (_stats.isScanning && !_stats.isPaused) {
      // Get next wallet based on strategy
      final wallet = await _scanningStrategyService.getNextWallet();
      
      // Check balances
      final balances = await _balanceChecker.checkAllBalances(wallet);
      
      // Update wallet with balances
      final walletWithBalances = Wallet(
        privateKey: wallet.privateKey,
        publicAddresses: wallet.publicAddresses,
        balances: balances,
      );
      
      // Process the wallet
      _processWallet(walletWithBalances);
      
      // Increment counter
      _stats.keysChecked++;
      
      // Add delay to avoid overwhelming APIs
      await Future.delayed(Duration(milliseconds: _scanDelay));
    }
  }
  
  // Process a wallet after checking its balance
  void _processWallet(Wallet wallet) {
    bool hasBalance = false;
    
    // Check if any balance exceeds threshold
    for (final entry in wallet.balances.entries) {
      final threshold = _balanceThresholds[entry.key] ?? 0.000001;
      if (entry.value > threshold) {
        hasBalance = true;
        break;
      }
    }
    
    if (hasBalance) {
      _processFoundWallet(wallet);
    }
  }
  
  // Handle a wallet with non-zero balance
  void _processFoundWallet(Wallet wallet) {
    _hitLog.addHit(wallet);
    _stats.hitsFound++;
    _lastFoundWallet = wallet;
    
    // Save the hit log
    _storageService.saveHitLog(_hitLog);
    
    // Notify listeners of found wallet
    _walletFoundController.add(wallet);
    
    // Stop scanning if wallet has significant balance
    bool hasSeriousBalance = false;
    for (final entry in wallet.balances.entries) {
      final threshold = (_balanceThresholds[entry.key] ?? 0.000001) * 10;
      if (entry.value > threshold) {
        hasSeriousBalance = true;
        break;
      }
    }
    
    if (hasSeriousBalance) {
      stopScanning();
    }
    
    notifyListeners();
  }
  
  // Pause wallet scanning
  void pauseScanning() {
    if (_stats.isScanning && !_stats.isPaused) {
      _stats.pause();
      notifyListeners();
    }
  }
  
  // Stop wallet scanning
  Future<void> stopScanning() async {
    if (_stats.isScanning) {
      _stats.stop();
      
      // Stop update timer
      _progressUpdateTimer?.cancel();
      
      // Stop all isolates
      _stopIsolates();
      
      notifyListeners();
    }
  }
  
  // Stop all running isolates
  void _stopIsolates() {
    for (final isolate in _scanningIsolates) {
      isolate.kill(priority: Isolate.immediate);
    }
    _scanningIsolates.clear();
    
    for (final port in _receivePorts) {
      port.close();
    }
    _receivePorts.clear();
  }
  
  // Advanced settings for feature toggling
  Map<String, dynamic>? _advancedSettings;
  
  // Get advanced settings
  Map<String, dynamic>? getAdvancedSettings() {
    return _advancedSettings;
  }
  
  // Update advanced settings
  Future<void> updateAdvancedSettings(Map<String, dynamic> settings) async {
    _advancedSettings = settings;
    
    // Update cryptocurrencies to scan
    final selectedCryptos = settings['selectedCryptos'] as Map<String, dynamic>?;
    if (selectedCryptos != null) {
      _balanceChecker.updateEnabledCryptocurrencies(selectedCryptos.map(
        (key, value) => MapEntry(
          CryptocurrencyType.values.firstWhere(
            (type) => type.toString().split('.').last == key,
            orElse: () => CryptocurrencyType.BTC,
          ),
          value as bool,
        ),
      ));
    }
    
    // Update API settings
    final useSoChain = settings['useSoChain'] as bool?;
    final useBlockchair = settings['useBlockchair'] as bool?;
    final useEtherscan = settings['useEtherscan'] as bool?;
    
    if (useSoChain != null || useBlockchair != null || useEtherscan != null) {
      _balanceChecker.updateEnabledApis(
        useSoChain: useSoChain ?? true,
        useBlockchair: useBlockchair ?? true,
        useEtherscan: useEtherscan ?? true,
      );
    }
    
    // Update scanning features
    final useRandomGeneration = settings['useRandomGeneration'] as bool?;
    final useBrainWallets = settings['useBrainWallets'] as bool?;
    final useVanityAddresses = settings['useVanityAddresses'] as bool?;
    final useTargetedRanges = settings['useTargetedRanges'] as bool?;
    final useDictionaryAttack = settings['useDictionaryAttack'] as bool?;
    final useWeakPatterns = settings['useWeakPatterns'] as bool?;
    
    // Update scanning strategy service with enabled features
    _scanningStrategyService.updateEnabledFeatures(
      useRandomGeneration: useRandomGeneration ?? true,
      useBrainWallets: useBrainWallets ?? true,
      useVanityAddresses: useVanityAddresses ?? true,
      useTargetedRanges: useTargetedRanges ?? true,
      useDictionaryAttack: useDictionaryAttack ?? true,
      useWeakPatterns: useWeakPatterns ?? true,
    );
    
    // Save advanced settings to storage
    await _storageService.saveAdvancedSettings(_advancedSettings!);
    notifyListeners();
  }
  
  // Update scanner settings
  Future<void> updateSettings({
    bool? backgroundMode,
    int? scanDelay,
    int? apiRateLimit,
    int? numThreads,
    int? batchSize,
    ScanningStrategy? scanningStrategy,
    bool? useBrainWallet,
    String? brainWalletPhrase,
    Map<CryptocurrencyType, double>? thresholds,
  }) async {
    if (backgroundMode != null) {
      _backgroundMode = backgroundMode;
    }
    
    if (scanDelay != null) {
      _scanDelay = scanDelay;
    }
    
    if (apiRateLimit != null) {
      _apiRateLimit = apiRateLimit;
    }
    
    if (numThreads != null) {
      _numThreads = numThreads;
    }
    
    if (batchSize != null) {
      _batchSize = batchSize;
    }
    
    if (scanningStrategy != null) {
      _scanningStrategy = scanningStrategy;
      _scanningStrategyService.setStrategy(scanningStrategy);
    }
    
    if (useBrainWallet != null) {
      _useBrainWallet = useBrainWallet;
    }
    
    if (brainWalletPhrase != null) {
      _brainWalletPhrase = brainWalletPhrase;
      if (_useBrainWallet && _brainWalletPhrase.isNotEmpty) {
        _scanningStrategyService.setBrainWalletPhrase(_brainWalletPhrase);
      }
    }
    
    if (thresholds != null) {
      _balanceThresholds = thresholds;
    }
    
    // Save settings
    final settings = {
      'backgroundScan': _backgroundMode,
      'scanDelay': _scanDelay,
      'apiRateLimit': _apiRateLimit,
      'numThreads': _numThreads,
      'batchSize': _batchSize,
      'scanningStrategy': _scanningStrategy.toString().split('.').last,
      'useBrainWallet': _useBrainWallet,
      'brainWalletPhrase': _brainWalletPhrase,
      'balanceThresholds': _balanceThresholds.map((k, v) => MapEntry(k.toString().split('.').last, v)),
    };
    
    await _storageService.saveSettings(settings);
    notifyListeners();
  }
  
  // Quick check of balance for a specific wallet
  Future<Map<CryptocurrencyType, double>> startWalletBalanceCheck(Wallet wallet) async {
    return await _balanceChecker.checkAllBalances(wallet);
  }
  
  // Export hits to a file
  Future<String?> exportHits() async {
    return _storageService.exportHitLog();
  }
  
  // Get advanced settings for the UI
  Map<String, dynamic>? getAdvancedSettings() {
    // Try to load advanced settings from storage
    return _storageService.loadAdvancedSettingsSync();
  }
  
  // Update and save advanced settings
  Future<void> updateAdvancedSettings(Map<String, dynamic> advancedSettings) async {
    // Update API settings
    final useSoChain = advancedSettings['useSoChain'] as bool?;
    final useBlockchair = advancedSettings['useBlockchair'] as bool?;
    final useEtherscan = advancedSettings['useEtherscan'] as bool?;
    
    if (useSoChain != null || useBlockchair != null || useEtherscan != null) {
      _balanceChecker.updateEnabledApis(
        useSoChain: useSoChain,
        useBlockchair: useBlockchair,
        useEtherscan: useEtherscan,
      );
    }
    
    // Update scanning features
    final useRandomGeneration = advancedSettings['useRandomGeneration'] as bool?;
    final useBrainWallets = advancedSettings['useBrainWallets'] as bool?;
    final useVanityAddresses = advancedSettings['useVanityAddresses'] as bool?;
    final useTargetedRanges = advancedSettings['useTargetedRanges'] as bool?;
    final useDictionaryAttack = advancedSettings['useDictionaryAttack'] as bool?;
    final useWeakPatterns = advancedSettings['useWeakPatterns'] as bool?;
    final useHdWalletDerivation = advancedSettings['useHdWalletDerivation'] as bool?;
    
    if (useRandomGeneration != null || useBrainWallets != null || 
        useVanityAddresses != null || useTargetedRanges != null ||
        useDictionaryAttack != null || useWeakPatterns != null ||
        useHdWalletDerivation != null) {
      _scanningStrategyService.updateEnabledFeatures(
        useRandomGeneration: useRandomGeneration,
        useBrainWallets: useBrainWallets,
        useVanityAddresses: useVanityAddresses,
        useTargetedRanges: useTargetedRanges,
        useDictionaryAttack: useDictionaryAttack,
        useWeakPatterns: useWeakPatterns,
        useHdWalletDerivation: useHdWalletDerivation,
      );
    }
    
    // Update cryptocurrency selection
    final selectedCryptos = advancedSettings['selectedCryptos'] as Map<String, dynamic>?;
    if (selectedCryptos != null) {
      final cryptoMap = <CryptocurrencyType, bool>{};
      for (final type in CryptocurrencyType.values) {
        final typeName = type.toString().split('.').last;
        cryptoMap[type] = selectedCryptos[typeName] ?? true;
      }
      _balanceChecker.updateEnabledCryptocurrencies(cryptoMap);
    }
    
    // Save to storage
    await _storageService.saveAdvancedSettings(advancedSettings);
  }
  
  // Clear hit log
  Future<void> clearHitLog() async {
    _hitLog.clear();
    await _storageService.saveHitLog(_hitLog);
    notifyListeners();
  }
  
  // Generate vanity wallet with specific pattern
  Future<Wallet?> generateVanityWallet({
    required CryptocurrencyType cryptoType,
    required String pattern,
  }) async {
    try {
      return await _vanityAddressService.generateVanityWallet(
        cryptoType: cryptoType,
        prefix: pattern,
        maxAttempts: 10000,
      );
    } catch (e) {
      return null;
    }
  }
  
  // Generate a wallet from a brain wallet phrase
  Future<Wallet> generateBrainWallet(String phrase) async {
    final privateKey = _brainWalletService.generatePrivateKeyFromPassphrase(phrase);
    return _walletGenerator.generateWalletFromPrivateKey(privateKey);
  }
  
  // Run a dictionary attack on common phrases
  Future<void> runDictionaryAttack({int limit = 100}) async {
    if (_stats.isScanning) {
      throw Exception('Scanner is already running');
    }
    
    _stats.startScanning();
    _stats.setStatus('Running dictionary attack...');
    notifyListeners();
    
    try {
      // Get common phrases from the brain wallet service
      final phrases = _brainWalletService.generateCommonPhrases();
      
      // Limit the number of phrases to check
      final limitedPhrases = phrases.take(limit).toList();
      _stats.setTotalWallets(limitedPhrases.length);
      
      // Check each phrase
      for (int i = 0; i < limitedPhrases.length; i++) {
        if (!_stats.isScanning || _stats.isPaused) {
          break;
        }
        
        final phrase = limitedPhrases[i];
        final wallet = await generateBrainWallet(phrase);
        
        // Update stats
        _stats.incrementCheckedWallets();
        _stats.setCurrentDetails('Checking brain wallet: $phrase');
        notifyListeners();
        
        // Check balances
        final balances = await _balanceChecker.checkAllBalances(wallet);
        
        // Check if any balance is above threshold
        bool hasBalance = false;
        for (final entry in balances.entries) {
          final threshold = _balanceThresholds[entry.key] ?? 0.0;
          if (entry.value > threshold) {
            hasBalance = true;
            break;
          }
        }
        
        // Record hit if balance found
        if (hasBalance) {
          final walletWithBalance = Wallet(
            privateKey: wallet.privateKey,
            publicAddresses: wallet.publicAddresses,
            balances: balances,
            createdAt: DateTime.now(),
            metadata: {'brain_wallet_phrase': phrase},
          );
          
          _hitLog.addHit(walletWithBalance);
          _stats.incrementHits();
          _lastFoundWallet = walletWithBalance;
          
          // Notify wallet found
          _walletFoundController.add(walletWithBalance);
          
          await _storageService.saveHitLog(_hitLog);
          notifyListeners();
        }
        
        // Add delay to avoid API rate limiting
        await Future.delayed(Duration(milliseconds: _scanDelay));
      }
      
      _stats.stopScanning();
      _stats.setStatus('Dictionary attack completed');
    } catch (e) {
      _stats.setError('Error: ${e.toString()}');
      _stats.stopScanning();
    } finally {
      notifyListeners();
    }
  }
  
  // Load private keys from a file and scan them
  Future<void> scanFromFile(String filePath) async {
    if (_stats.isScanning) {
      await stopScanning();
    }
    
    final privateKeys = await _walletGenerator.loadPrivateKeysFromFile(filePath);
    
    if (privateKeys.isEmpty) {
      return;
    }
    
    _stats.reset();
    _stats.start();
    
    // Start periodic update of UI
    _progressUpdateTimer = Timer.periodic(const Duration(milliseconds: 250), (_) {
      notifyListeners();
    });
    
    // Process in batches for efficiency
    final batchSize = 5;
    for (int i = 0; i < privateKeys.length; i += batchSize) {
      if (!_stats.isScanning || _stats.isPaused) {
        break;
      }
      
      final endIndex = (i + batchSize < privateKeys.length) ? i + batchSize : privateKeys.length;
      final batch = privateKeys.sublist(i, endIndex);
      
      await Future.wait(batch.map((privateKey) async {
        // Generate wallet
        final wallet = await _walletGenerator.generateWalletFromPrivateKey(privateKey);
        
        // Check balances
        final balances = await _balanceChecker.checkAllBalances(wallet);
        
        // Update wallet with balances
        final walletWithBalances = Wallet(
          privateKey: wallet.privateKey,
          publicAddresses: wallet.publicAddresses,
          balances: balances,
        );
        
        // Process the wallet
        _processWallet(walletWithBalances);
        
        // Increment counter
        _stats.keysChecked++;
      }));
      
      notifyListeners();
      
      // Add delay to avoid overwhelming APIs
      await Future.delayed(Duration(milliseconds: _scanDelay));
    }
    
    _stats.stop();
    _progressUpdateTimer?.cancel();
    notifyListeners();
  }
  
  // Run dictionary attack to check common brain wallet phrases
  Future<void> runDictionaryAttack({int limit = 100}) async {
    if (_stats.isScanning) {
      await stopScanning();
    }
    
    _stats.reset();
    _stats.start();
    
    // Start periodic update of UI
    _progressUpdateTimer = Timer.periodic(const Duration(milliseconds: 250), (_) {
      notifyListeners();
    });
    
    // Get dictionary attack keys
    final privateKeys = _brainWalletService.generateDictionaryAttackPrivateKeys(limit);
    
    // Process in batches for efficiency
    final batchSize = 5;
    for (int i = 0; i < privateKeys.length; i += batchSize) {
      if (!_stats.isScanning || _stats.isPaused) {
        break;
      }
      
      final endIndex = (i + batchSize < privateKeys.length) ? i + batchSize : privateKeys.length;
      final batch = privateKeys.sublist(i, endIndex);
      
      await Future.wait(batch.map((privateKey) async {
        // Generate wallet
        final wallet = await _walletGenerator.generateWalletFromPrivateKey(privateKey);
        
        // Check balances
        final balances = await _balanceChecker.checkAllBalances(wallet);
        
        // Update wallet with balances
        final walletWithBalances = Wallet(
          privateKey: wallet.privateKey,
          publicAddresses: wallet.publicAddresses,
          balances: balances,
        );
        
        // Process the wallet
        _processWallet(walletWithBalances);
        
        // Increment counter
        _stats.keysChecked++;
      }));
      
      notifyListeners();
      
      // Add delay to avoid overwhelming APIs
      await Future.delayed(Duration(milliseconds: _scanDelay));
    }
    
    _stats.stop();
    _progressUpdateTimer?.cancel();
    notifyListeners();
  }
  
  @override
  void dispose() {
    _progressUpdateTimer?.cancel();
    stopScanning();
    _walletFoundController.close();
    _stopIsolates();
    super.dispose();
  }
}
