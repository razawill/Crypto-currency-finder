import 'dart:math';
import 'wallet_generator.dart';
import 'address_derivation.dart';
import '../models/wallet.dart';

class VanityAddressService {
  final WalletGenerator _walletGenerator = WalletGenerator();
  final Random _random = Random.secure();
  
  // Generate a wallet with an address that starts with the specified pattern
  Future<Wallet> generateVanityWallet({
    required CryptocurrencyType cryptoType,
    required String prefix,
    int maxAttempts = 100000,
  }) async {
    int attempts = 0;
    
    while (attempts < maxAttempts) {
      attempts++;
      
      // Generate a random private key
      final privateKey = _walletGenerator.generatePrivateKey();
      
      // Generate the wallet for all cryptocurrencies
      final wallet = await _walletGenerator.generateWalletFromPrivateKey(privateKey);
      
      // Check if the address for the specified crypto type starts with the prefix
      final address = wallet.publicAddresses[cryptoType];
      if (address != null && addressMatchesPattern(address, prefix, cryptoType)) {
        return wallet;
      }
    }
    
    throw Exception('Could not find a vanity address after $maxAttempts attempts');
  }
  
  // Check if an address matches the specified pattern
  bool addressMatchesPattern(String address, String pattern, CryptocurrencyType cryptoType) {
    // For ETH addresses, ignore the '0x' prefix if comparing
    if (cryptoType == CryptocurrencyType.ETH && address.startsWith('0x')) {
      return address.substring(2).toLowerCase().startsWith(pattern.toLowerCase());
    }
    
    return address.toLowerCase().startsWith(pattern.toLowerCase());
  }
  
  // Generate a wallet with an address that contains the specified pattern anywhere
  Future<Wallet> generateWalletWithPattern({
    required CryptocurrencyType cryptoType,
    required String pattern,
    int maxAttempts = 100000,
  }) async {
    int attempts = 0;
    
    while (attempts < maxAttempts) {
      attempts++;
      
      // Generate a random private key
      final privateKey = _walletGenerator.generatePrivateKey();
      
      // Generate the wallet
      final wallet = await _walletGenerator.generateWalletFromPrivateKey(privateKey);
      
      // Check if the address for the specified crypto type contains the pattern
      final address = wallet.publicAddresses[cryptoType];
      if (address != null && addressContainsPattern(address, pattern, cryptoType)) {
        return wallet;
      }
    }
    
    throw Exception('Could not find an address with the pattern after $maxAttempts attempts');
  }
  
  // Check if an address contains the specified pattern
  bool addressContainsPattern(String address, String pattern, CryptocurrencyType cryptoType) {
    String normalizedAddress = address;
    
    // For ETH addresses, handle the '0x' prefix
    if (cryptoType == CryptocurrencyType.ETH && address.startsWith('0x')) {
      normalizedAddress = address.substring(2);
    }
    
    return normalizedAddress.toLowerCase().contains(pattern.toLowerCase());
  }
  
  // Generate a wallet with a "rich-looking" address (many leading zeros, etc.)
  Future<Wallet> generateRichLookingWallet({
    required CryptocurrencyType cryptoType,
    int maxAttempts = 100000,
  }) async {
    int attempts = 0;
    
    while (attempts < maxAttempts) {
      attempts++;
      
      // Generate a random private key
      final privateKey = _walletGenerator.generatePrivateKey();
      
      // Generate the wallet
      final wallet = await _walletGenerator.generateWalletFromPrivateKey(privateKey);
      
      // Check if the address has a rich-looking pattern
      final address = wallet.publicAddresses[cryptoType];
      if (address != null && isRichLookingAddress(address, cryptoType)) {
        return wallet;
      }
    }
    
    throw Exception('Could not find a rich-looking address after $maxAttempts attempts');
  }
  
  // Check if an address looks "rich" based on patterns
  bool isRichLookingAddress(String address, CryptocurrencyType cryptoType) {
    String normalizedAddress = address;
    
    // For ETH addresses, handle the '0x' prefix
    if (cryptoType == CryptocurrencyType.ETH && address.startsWith('0x')) {
      normalizedAddress = address.substring(2);
    }
    
    // Check for repeated characters (e.g., '111111', 'aaaaaa')
    final repeatedCharsPattern = RegExp(r'([a-zA-Z0-9])\1{5,}');
    if (repeatedCharsPattern.hasMatch(normalizedAddress)) {
      return true;
    }
    
    // Check for leading zeros
    if (normalizedAddress.startsWith('000')) {
      return true;
    }
    
    // Check for palindromes (reads the same forward and backward)
    final len = normalizedAddress.length;
    final halfLen = len ~/ 2;
    for (int i = 0; i < halfLen; i++) {
      if (normalizedAddress[i] != normalizedAddress[len - 1 - i]) {
        return false;
      }
    }
    
    // Check for ascending or descending sequences
    bool hasAscendingSequence = false;
    bool hasDescendingSequence = false;
    
    for (int i = 0; i < normalizedAddress.length - 5; i++) {
      final charCodes = normalizedAddress.substring(i, i + 6).codeUnits;
      bool isAscending = true;
      bool isDescending = true;
      
      for (int j = 1; j < charCodes.length; j++) {
        if (charCodes[j] != charCodes[j - 1] + 1) {
          isAscending = false;
        }
        if (charCodes[j] != charCodes[j - 1] - 1) {
          isDescending = false;
        }
      }
      
      if (isAscending) {
        hasAscendingSequence = true;
        break;
      }
      
      if (isDescending) {
        hasDescendingSequence = true;
        break;
      }
    }
    
    return hasAscendingSequence || hasDescendingSequence;
  }
  
  // Generate a set of private keys with specific patterns in their corresponding addresses
  Future<List<String>> generatePrivateKeysWithAddressPatterns({
    required CryptocurrencyType cryptoType,
    required List<String> patterns,
    int keysPerPattern = 1,
    int maxAttemptsPerPattern = 10000,
  }) async {
    final List<String> privateKeys = [];
    
    for (final pattern in patterns) {
      int found = 0;
      int attempts = 0;
      
      while (found < keysPerPattern && attempts < maxAttemptsPerPattern) {
        attempts++;
        
        // Generate a random private key
        final privateKey = _walletGenerator.generatePrivateKey();
        
        // Generate the wallet to check the address
        final wallet = await _walletGenerator.generateWalletFromPrivateKey(privateKey);
        
        // Check if address contains the pattern
        final address = wallet.publicAddresses[cryptoType];
        if (address != null && addressContainsPattern(address, pattern, cryptoType)) {
          privateKeys.add(privateKey);
          found++;
        }
      }
    }
    
    return privateKeys;
  }
}