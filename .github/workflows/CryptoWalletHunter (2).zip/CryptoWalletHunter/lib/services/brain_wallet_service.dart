import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:convert/convert.dart';
import 'package:pointycastle/digests/sha256.dart';
import 'package:web3dart/crypto.dart';
import 'package:bip39/bip39.dart' as bip39;
import '../models/wallet.dart';
import 'wallet_generator.dart';

class BrainWalletService {
  // Generate a private key from a passphrase using SHA-256
  String generatePrivateKeyFromPassphrase(String passphrase) {
    final bytes = utf8.encode(passphrase);
    final digest = sha256.convert(bytes);
    return hex.encode(digest.bytes);
  }
  
  // Generate a private key from common phrases
  String generatePrivateKeyFromCommonPhrase(String phrase, int index) {
    final indexedPhrase = '$phrase-$index';
    return generatePrivateKeyFromPassphrase(indexedPhrase);
  }
  
  // Generate a private key from a dictionary word and salt
  String generatePrivateKeyFromWordAndSalt(String word, String salt) {
    final combinedString = '$word-$salt';
    return generatePrivateKeyFromPassphrase(combinedString);
  }
  
  // Generate a private key from a BIP39 mnemonic phrase
  String generatePrivateKeyFromMnemonic(String mnemonic, {String passphrase = ''}) {
    if (!bip39.validateMnemonic(mnemonic)) {
      throw Exception('Invalid mnemonic phrase');
    }
    
    final seed = bip39.mnemonicToSeed(mnemonic, passphrase: passphrase);
    final seedHex = hex.encode(seed);
    // Use the first 32 bytes as the private key
    return seedHex.substring(0, 64);
  }
  
  // Generate a private key from a known pattern
  String generatePrivateKeyFromPattern(String pattern, int iteration) {
    final combinedString = '$pattern-$iteration';
    return generatePrivateKeyFromPassphrase(combinedString);
  }
  
  // Generate a HD wallet path key from master key
  String deriveChildKey(String masterKey, int index) {
    final masterKeyBytes = hex.decode(masterKey);
    final indexBytes = intToBytes(index);
    
    final combined = [...masterKeyBytes, ...indexBytes];
    final digest = sha256.convert(combined);
    return hex.encode(digest.bytes);
  }
  
  // Convert int to bytes for derivation
  List<int> intToBytes(int value) {
    final buffer = ByteData(4);
    buffer.setInt32(0, value);
    return [buffer.getUint8(0), buffer.getUint8(1), buffer.getUint8(2), buffer.getUint8(3)];
  }
  
  // Generate a wallet from a phrase
  Future<Wallet> generateFromPhrase(String phrase) async {
    final privateKey = generatePrivateKeyFromPassphrase(phrase);
    final walletGenerator = WalletGenerator();
    return walletGenerator.generateWalletFromPrivateKey(privateKey);
  }
  
  // Generate a list of common brain wallet phrases to try
  List<String> generateCommonPhrases() {
    return [
      'correct horse battery staple',
      'to be or not to be',
      'password',
      'qwerty',
      '123456',
      'letmein',
      'trustno1',
      'sunshine',
      'welcome',
      'monkey',
      'football',
      'bitcoin',
      'satoshi',
      'nakamoto',
      'blockchain',
      'cryptocurrency',
      'ethereum',
      'wallet',
      'private key',
      'genesis block',
      'digital gold',
      'hodl',
      'to the moon',
      'diamond hands',
      'doge to the moon',
      'vitalik',
      'buterin',
      'crypto',
      'decentralize',
      'freedom',
      'libertarian',
      'anarchy',
      'anonymous',
      'secure',
      'peer to peer',
      'digital cash',
      'fiat',
      'inflation',
      'federal reserve'
    ];
  }
  
  // Generate private keys from popular song lyrics, quotes, etc.
  List<String> generatePopularPhrasesPrivateKeys() {
    final phrases = [
      'all you need is love',
      'imagine all the people',
      'to infinity and beyond',
      'may the force be with you',
      'life is like a box of chocolates',
      'houston we have a problem',
      'show me the money',
      'you talking to me',
      'i\'ll be back',
      'say hello to my little friend'
    ];
    
    final privateKeys = <String>[];
    for (final phrase in phrases) {
      privateKeys.add(generatePrivateKeyFromPassphrase(phrase));
    }
    
    return privateKeys;
  }
  
  // Generate variations of common patterns
  List<String> generateVariationsOfPassphrase(String basePhrase, int count) {
    final variations = <String>[];
    
    for (int i = 0; i < count; i++) {
      // Add numbers to the end
      variations.add(generatePrivateKeyFromPassphrase('$basePhrase$i'));
      
      // Add common suffixes
      variations.add(generatePrivateKeyFromPassphrase('${basePhrase}123'));
      variations.add(generatePrivateKeyFromPassphrase('${basePhrase}!'));
      variations.add(generatePrivateKeyFromPassphrase('${basePhrase}Password'));
      
      // Simple letter substitutions
      final substituted = basePhrase
          .replaceAll('a', '4')
          .replaceAll('e', '3')
          .replaceAll('i', '1')
          .replaceAll('o', '0');
      variations.add(generatePrivateKeyFromPassphrase(substituted));
    }
    
    return variations;
  }
  
  // Generate dictionary attack private keys (uses common passwords/phrases)
  List<String> generateDictionaryAttackPrivateKeys(int limit) {
    final commonPhrases = generateCommonPhrases();
    final privateKeys = <String>[];
    
    for (int i = 0; i < commonPhrases.length && privateKeys.length < limit; i++) {
      privateKeys.add(generatePrivateKeyFromPassphrase(commonPhrases[i]));
      
      // Add some variations
      final variations = generateVariationsOfPassphrase(commonPhrases[i], 3);
      for (final variation in variations) {
        if (privateKeys.length < limit) {
          privateKeys.add(variation);
        } else {
          break;
        }
      }
    }
    
    return privateKeys;
  }
}