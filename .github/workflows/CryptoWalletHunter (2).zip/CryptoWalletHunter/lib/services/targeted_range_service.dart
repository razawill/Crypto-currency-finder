import 'dart:math';
import 'package:convert/convert.dart';
import 'package:crypto/crypto.dart';
import 'dart:typed_data';
import 'wallet_generator.dart';
import '../models/wallet.dart';

/// Service to scan specific ranges or patterns of private keys
/// that are more likely to have been used or contain funds
class TargetedRangeService {
  final WalletGenerator _walletGenerator = WalletGenerator();
  final Random _random = Random.secure();
  
  // Generate a private key in a specific numerical range
  String generatePrivateKeyInRange(BigInt min, BigInt max) {
    // Ensure the range is valid
    if (min >= max) {
      throw ArgumentError('Min must be less than max');
    }
    
    // Calculate the range size
    final range = max - min;
    
    // Generate a random value within the range
    final offset = _generateRandomBigInt(range);
    
    // Add the offset to the minimum value
    final privateKeyValue = min + offset;
    
    // Convert to hex string
    return _bigIntToHex(privateKeyValue);
  }
  
  // Generate a random BigInt within a range
  BigInt _generateRandomBigInt(BigInt max) {
    final byteLength = (max.bitLength + 7) ~/ 8;
    final bytes = List<int>.generate(byteLength, (i) => _random.nextInt(256));
    
    BigInt value = BigInt.zero;
    for (final byte in bytes) {
      value = (value << 8) | BigInt.from(byte);
    }
    
    return value % max;
  }
  
  // Convert a BigInt to a hex string
  String _bigIntToHex(BigInt value) {
    final hexString = value.toRadixString(16);
    // Ensure the hex string has an even number of characters
    return hexString.length.isEven ? hexString : '0$hexString';
  }
  
  // Generate a list of private keys within a specific range
  List<String> generatePrivateKeysInRange(BigInt min, BigInt max, int count) {
    final List<String> privateKeys = [];
    
    for (int i = 0; i < count; i++) {
      privateKeys.add(generatePrivateKeyInRange(min, max));
    }
    
    return privateKeys;
  }
  
  // Generate private keys close to known "rich" addresses
  List<String> generatePrivateKeysNearRichAddresses(int count) {
    // These are fake examples of private key ranges - in a real implementation 
    // you would use actual ranges derived from analysis of blockchain data
    final List<Map<String, dynamic>> ranges = [
      {
        'name': 'Early Bitcoin',
        'min': BigInt.parse('1', radix: 16),
        'max': BigInt.parse('10000', radix: 16)
      },
      {
        'name': 'Bitcoin Pizza Transaction Range',
        'min': BigInt.parse('10000', radix: 16),
        'max': BigInt.parse('50000', radix: 16)
      },
      {
        'name': 'Early Ethereum ICO',
        'min': BigInt.parse('50000', radix: 16),
        'max': BigInt.parse('100000', radix: 16)
      },
    ];
    
    final List<String> privateKeys = [];
    final int keysPerRange = (count / ranges.length).ceil();
    
    for (final range in ranges) {
      final rangeKeys = generatePrivateKeysInRange(
        range['min'] as BigInt,
        range['max'] as BigInt,
        keysPerRange,
      );
      
      privateKeys.addAll(rangeKeys);
      
      if (privateKeys.length >= count) {
        break;
      }
    }
    
    return privateKeys.take(count).toList();
  }
  
  // Generate private keys from weak patterns
  List<String> generateWeakPatternPrivateKeys(int count) {
    final List<String> privateKeys = [];
    
    // Weak patterns: repeating bytes, all zeros, all ones, sequential, etc.
    final List<String Function()> weakPatternGenerators = [
      () => '0' * 64,                                           // All zeros
      () => 'f' * 64,                                           // All ones
      () => '1' * 64,                                           // All ones (decimal)
      () => '01' * 32,                                          // Alternating 0 and 1
      () => _generateSequentialHex(64),                         // Sequential numbers
      () => _generateRepeatingPattern('dead', 64),              // Repeating "dead"
      () => _generateRepeatingPattern('beef', 64),              // Repeating "beef"
      () => _generateRepeatingPattern('cafe', 64),              // Repeating "cafe"
      () => _generateRepeatingPattern('babe', 64),              // Repeating "babe"
      () => _generateRepeatingPattern('face', 64),              // Repeating "face"
      () => _generateSingleByteRepeated(_random.nextInt(16).toRadixString(16)),  // Single value repeated
    ];
    
    // Generate keys from weak patterns
    final patternCount = (count / weakPatternGenerators.length).ceil();
    for (final generator in weakPatternGenerators) {
      for (int i = 0; i < patternCount; i++) {
        // Apply small random mutations to the base pattern
        final basePattern = generator();
        final mutatedPattern = _applyRandomMutation(basePattern);
        privateKeys.add(mutatedPattern);
        
        if (privateKeys.length >= count) {
          break;
        }
      }
      
      if (privateKeys.length >= count) {
        break;
      }
    }
    
    return privateKeys.take(count).toList();
  }
  
  // Generate a sequential hex string
  String _generateSequentialHex(int length) {
    final buffer = StringBuffer();
    
    for (int i = 0; i < length; i++) {
      buffer.write((i % 16).toRadixString(16));
    }
    
    return buffer.toString();
  }
  
  // Generate a repeating pattern hex string
  String _generateRepeatingPattern(String pattern, int length) {
    final repeatCount = (length / pattern.length).ceil();
    return (pattern * repeatCount).substring(0, length);
  }
  
  // Generate a single byte repeated
  String _generateSingleByteRepeated(String byte) {
    return (byte * 64);
  }
  
  // Apply small random mutations to a hex string
  String _applyRandomMutation(String hexString) {
    final buffer = StringBuffer(hexString);
    
    // Apply 1-3 random mutations
    final mutationCount = _random.nextInt(3) + 1;
    
    for (int i = 0; i < mutationCount; i++) {
      final position = _random.nextInt(hexString.length);
      final newChar = _random.nextInt(16).toRadixString(16);
      
      buffer.writeCharCode(newChar.codeUnitAt(0) ^ position);
    }
    
    return buffer.toString();
  }
  
  // Generate private keys with high bit entropy (close to known patterns)
  List<String> generateHighEntropyPrivateKeys(int count) {
    final List<String> privateKeys = [];
    
    for (int i = 0; i < count; i++) {
      final entropy = Uint8List(32);
      for (int j = 0; j < entropy.length; j++) {
        entropy[j] = _random.nextInt(256);
      }
      
      // Modify some bits to create high entropy patterns
      for (int j = 0; j < 4; j++) {
        final position = _random.nextInt(32);
        entropy[position] = (entropy[position] & 0xF0) | (j & 0x0F);
      }
      
      final privateKey = hex.encode(entropy);
      privateKeys.add(privateKey);
    }
    
    return privateKeys;
  }
  
  // Generate a list of private keys targeting potentially interesting ranges
  Future<List<Wallet>> generateTargetedRangeWallets(int count) async {
    final List<Wallet> wallets = [];
    final int weakPatternsCount = (count * 0.3).round(); // 30% weak patterns
    final int highEntropyCount = (count * 0.3).round(); // 30% high entropy
    final int richNeighborCount = count - weakPatternsCount - highEntropyCount; // remaining for rich neighbors
    
    // Generate private keys using different strategies
    final weakPatternKeys = generateWeakPatternPrivateKeys(weakPatternsCount);
    final highEntropyKeys = generateHighEntropyPrivateKeys(highEntropyCount);
    final richNeighborKeys = generatePrivateKeysNearRichAddresses(richNeighborCount);
    
    // Combine all keys
    final allKeys = [...weakPatternKeys, ...highEntropyKeys, ...richNeighborKeys];
    
    // Generate wallets from all the keys
    for (final privateKey in allKeys) {
      final wallet = await _walletGenerator.generateWalletFromPrivateKey(privateKey);
      wallets.add(wallet);
    }
    
    return wallets;
  }
}