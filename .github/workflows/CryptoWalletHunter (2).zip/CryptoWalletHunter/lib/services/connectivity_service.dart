import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

class ConnectivityService extends ChangeNotifier {
  final Connectivity _connectivity = Connectivity();
  
  bool _hasConnection = true;
  StreamSubscription<ConnectivityResult>? _connectivitySubscription;
  
  bool get hasConnection => _hasConnection;
  
  Future<void> initialize() async {
    await checkConnectivity();
    _connectivitySubscription = _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);
  }
  
  // For backwards compatibility 
  Future<void> init() async {
    await initialize();
  }
  
  Future<void> checkConnectivity() async {
    try {
      final ConnectivityResult result = await _connectivity.checkConnectivity();
      _updateConnectionStatus(result);
    } catch (e) {
      debugPrint('Error checking connectivity: $e');
      _hasConnection = false;
      notifyListeners();
    }
  }
  
  void _updateConnectionStatus(ConnectivityResult result) {
    final bool hadConnection = _hasConnection;
    _hasConnection = result != ConnectivityResult.none;
    
    if (hadConnection != _hasConnection) {
      notifyListeners();
    }
  }
  
  @override
  void dispose() {
    _connectivitySubscription?.cancel();
    super.dispose();
  }
}
