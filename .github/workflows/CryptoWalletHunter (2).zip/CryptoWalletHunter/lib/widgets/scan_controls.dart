import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import '../services/scanner_service.dart';

class ScanControls extends StatelessWidget {
  const ScanControls({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<ScannerService>(
      builder: (context, scannerService, child) {
        final isScanning = scannerService.isScanning;
        final isPaused = scannerService.isPaused;
        
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Controls',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    if (!isScanning || isPaused)
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.play_arrow),
                          label: Text(isPaused ? 'Resume' : 'Start Scan'),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                          onPressed: () {
                            scannerService.startScanning();
                          },
                        ),
                      ),
                    
                    if (isScanning && !isPaused)
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.pause),
                          label: const Text('Pause'),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            backgroundColor: Colors.orange,
                          ),
                          onPressed: () {
                            scannerService.pauseScanning();
                          },
                        ),
                      ),
                      
                    if (isScanning)
                      const SizedBox(width: 8),
                      
                    if (isScanning)
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.stop),
                          label: const Text('Stop'),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            backgroundColor: Colors.red,
                          ),
                          onPressed: () {
                            scannerService.stopScanning();
                          },
                        ),
                      ),
                  ],
                ),
                
                const SizedBox(height: 16),
                
                OutlinedButton.icon(
                  icon: const Icon(Icons.file_upload),
                  label: const Text('Scan from File'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onPressed: isScanning 
                    ? null
                    : () async {
                        final result = await FilePicker.platform.pickFiles(
                          type: FileType.custom,
                          allowedExtensions: ['txt'],
                        );
                        
                        if (result != null && result.files.single.path != null) {
                          final filePath = result.files.single.path!;
                          
                          // Show confirmation dialog
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: const Text('Scan Private Keys'),
                              content: Text('Start scanning keys from ${result.files.single.name}?'),
                              actions: [
                                TextButton(
                                  child: const Text('Cancel'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                ),
                                ElevatedButton(
                                  child: const Text('Scan'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                    scannerService.scanFromFile(filePath);
                                  },
                                ),
                              ],
                            ),
                          );
                        }
                      },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
