import 'package:flutter/material.dart';
import '../models/wallet.dart';

class WalletCard extends StatelessWidget {
  final Wallet wallet;
  final VoidCallback? onTap;
  
  const WalletCard({
    Key? key,
    required this.wallet,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final totalBalance = wallet.getTotalBalance();
    final hasBalance = wallet.hasBalance;
    
    // Find non-zero balances
    final nonZeroBalances = wallet.balances.entries
        .where((entry) => entry.value > 0)
        .toList();
    
    return Card(
      elevation: 2,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: hasBalance
            ? BorderSide(color: Colors.green.shade300, width: 1.5)
            : BorderSide.none,
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Private key preview and time
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      'Key: ${wallet.privateKey.substring(0, 10)}...${wallet.privateKey.substring(wallet.privateKey.length - 10)}',
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Text(
                    _formatDate(wallet.createdAt),
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
              
              const SizedBox(height: 12),
              
              // Balances
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Balances:',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  if (hasBalance)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        'HIT',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                ],
              ),
              
              const SizedBox(height: 8),
              
              // Show non-zero balances
              if (nonZeroBalances.isNotEmpty)
                ...nonZeroBalances.map((entry) => Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          _getCryptoIcon(entry.key),
                          const SizedBox(width: 8),
                          Text(entry.key.toString().split('.').last),
                        ],
                      ),
                      Text(
                        '${entry.value}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                )).toList()
              else
                const Text(
                  'No balance found',
                  style: TextStyle(color: Colors.grey),
                ),
              
              const SizedBox(height: 8),
              
              // Additional info
              if (onTap != null)
                const Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    'Tap for details →',
                    style: TextStyle(
                      fontStyle: FontStyle.italic,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
  
  String _formatDate(DateTime dateTime) {
    return '${dateTime.year}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.day.toString().padLeft(2, '0')} ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }
  
  Widget _getCryptoIcon(CryptocurrencyType type) {
    IconData iconData;
    Color color;
    
    switch (type) {
      case CryptocurrencyType.BTC:
        iconData = Icons.currency_bitcoin;
        color = Colors.orange;
        break;
      case CryptocurrencyType.ETH:
        iconData = Icons.currency_exchange;
        color = Colors.blue;
        break;
      case CryptocurrencyType.DOGE:
        iconData = Icons.pets;
        color = Colors.amber;
        break;
      case CryptocurrencyType.LTC:
        iconData = Icons.attach_money;
        color = Colors.grey;
        break;
      case CryptocurrencyType.DASH:
        iconData = Icons.speed;
        color = Colors.blue;
        break;
      case CryptocurrencyType.SOL:
        iconData = Icons.solar_power;
        color = Colors.purple;
        break;
    }
    
    return Container(
      width: 24,
      height: 24,
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(
        iconData,
        color: color,
        size: 16,
      ),
    );
  }
}
