import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'theme/theme_provider.dart';
import 'services/connectivity_service.dart';
import 'services/storage_service.dart';
import 'services/scanner_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize services
  final storageService = StorageService();
  await storageService.init();
  
  final connectivityService = ConnectivityService();
  await connectivityService.init();
  
  // Run the app with providers
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        Provider<StorageService>.value(value: storageService),
        ChangeNotifierProvider<ConnectivityService>.value(value: connectivityService),
        ProxyProvider<StorageService, ScannerService>(
          update: (_, storageService, __) {
            return ScannerService(storageService);
          },
        ),
      ],
      child: const CryptoWalletDiscoveryApp(),
    ),
  );
}
