import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class ExportUtils {
  // Check and request storage permissions
  static Future<bool> checkStoragePermission() async {
    final status = await Permission.storage.status;
    if (status.isGranted) {
      return true;
    }
    
    final result = await Permission.storage.request();
    return result.isGranted;
  }
  
  // Get a directory for exports
  static Future<Directory?> getExportDirectory() async {
    try {
      if (Platform.isAndroid) {
        if (await checkStoragePermission()) {
          final directory = await getExternalStorageDirectory();
          return directory;
        }
      }
      
      // Fallback to application documents directory
      return await getApplicationDocumentsDirectory();
    } catch (e) {
      debugPrint('Error getting export directory: $e');
      return null;
    }
  }
  
  // Create export filename with timestamp
  static String createExportFilename(String prefix) {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return '${prefix}_$timestamp.txt';
  }
  
  // Export data to a file
  static Future<String?> exportToFile(String content, String filename) async {
    try {
      final directory = await getExportDirectory();
      if (directory == null) {
        return null;
      }
      
      final file = File('${directory.path}/$filename');
      await file.writeAsString(content);
      return file.path;
    } catch (e) {
      debugPrint('Error exporting to file: $e');
      return null;
    }
  }
}
