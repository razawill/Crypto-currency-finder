import 'wallet.dart';

class HitLog {
  final List<Wallet> hits;
  
  HitLog({List<Wallet>? hits}) : hits = hits ?? [];
  
  void addHit(Wallet wallet) {
    if (!hits.any((hit) => hit.privateKey == wallet.privateKey)) {
      hits.add(wallet);
    }
  }
  
  void clear() {
    hits.clear();
  }
  
  List<Map<String, dynamic>> toJson() {
    return hits.map((wallet) => wallet.toJson()).toList();
  }
  
  factory HitLog.fromJson(List<Map<String, dynamic>> json) {
    return HitLog(
      hits: json.map((walletJson) => Wallet.fromJson(walletJson)).toList(),
    );
  }
  
  // Get threshold for a specific cryptocurrency type
  double? getThreshold(CryptocurrencyType type) {
    // Default minimum thresholds for different cryptocurrencies
    final Map<CryptocurrencyType, double> defaultThresholds = {
      CryptocurrencyType.BTC: 0.00001,  // Very small amount of Bitcoin
      CryptocurrencyType.ETH: 0.0001,   // Very small amount of Ethereum
      CryptocurrencyType.DOGE: 1.0,     // 1 DOGE
      CryptocurrencyType.LTC: 0.001,    // Small amount of Litecoin
      CryptocurrencyType.DASH: 0.001,   // Small amount of Dash
    };
    
    return defaultThresholds[type];
  }
}

class ScanStats {
  int keysChecked = 0;
  int hitsFound = 0;
  DateTime? startTime;
  DateTime? endTime;
  bool isScanning = false;
  bool isPaused = false;
  String currentStatus = 'Ready';
  String currentDetails = '';
  String? errorMessage;
  int totalWallets = 0;
  
  void reset() {
    keysChecked = 0;
    hitsFound = 0;
    startTime = null;
    endTime = null;
    isScanning = false;
    isPaused = false;
    currentStatus = 'Ready';
    currentDetails = '';
    errorMessage = null;
    totalWallets = 0;
  }
  
  void startScanning() {
    if (!isScanning) {
      startTime = DateTime.now();
      isScanning = true;
      isPaused = false;
      currentStatus = 'Scanning';
    }
  }
  
  void pause() {
    isPaused = true;
    currentStatus = 'Paused';
  }
  
  void resume() {
    isPaused = false;
    currentStatus = 'Scanning';
  }
  
  void stopScanning() {
    endTime = DateTime.now();
    isScanning = false;
    isPaused = false;
    currentStatus = 'Stopped';
  }
  
  void setStatus(String status) {
    currentStatus = status;
  }
  
  void setCurrentDetails(String details) {
    currentDetails = details;
  }
  
  void setError(String error) {
    errorMessage = error;
    currentStatus = 'Error';
  }
  
  void setTotalWallets(int total) {
    totalWallets = total;
  }
  
  void incrementCheckedWallets() {
    keysChecked++;
  }
  
  void incrementHits() {
    hitsFound++;
  }
  
  // Same as original start but renamed for clarity
  void start() {
    startScanning();
  }
  
  // Same as original stop but renamed for clarity
  void stop() {
    stopScanning();
  }
  
  Duration get duration {
    if (startTime == null) {
      return Duration.zero;
    }
    
    if (isScanning) {
      return DateTime.now().difference(startTime!);
    }
    
    if (endTime != null) {
      return endTime!.difference(startTime!);
    }
    
    return Duration.zero;
  }
  
  double get keysPerSecond {
    final seconds = duration.inSeconds;
    if (seconds == 0) return 0;
    return keysChecked / seconds;
  }
}
