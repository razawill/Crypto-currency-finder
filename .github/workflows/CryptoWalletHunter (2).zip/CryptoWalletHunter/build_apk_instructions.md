# Building the Crypto Wallet Discovery App APK

This document provides instructions for building the APK for the Crypto Wallet Discovery app so you can install it on your Android device.

## Prerequisites

1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. Install Android Studio: https://developer.android.com/studio
3. Configure Flutter with Android Studio: https://flutter.dev/docs/get-started/editor?tab=androidstudio
4. Connect your Android device or set up an emulator

## Building the APK

### Method 1: Using Flutter CLI

1. Clone this repository to your local machine
2. Navigate to the project directory
3. Run the following command to build a debug APK:
   ```
   flutter build apk --debug
   ```
4. Or for a release APK (optimized for deployment):
   ```
   flutter build apk --release
   ```
5. The APK will be located at:
   ```
   build/app/outputs/flutter-apk/app-debug.apk
   ```
   or
   ```
   build/app/outputs/flutter-apk/app-release.apk
   ```

### Method 2: Using Android Studio

1. Open the project in Android Studio
2. Select 'Build' > 'Flutter' > 'Build APK'
3. The APK will be generated in the build directory

## Installing on Your Device

### Method 1: Direct Transfer

1. Connect your Android device to your computer via USB
2. Enable file transfer on your Android device
3. Copy the APK file to your device
4. On your device, navigate to the APK file location using a file manager
5. Tap the APK file to install (you may need to enable installation from unknown sources)

### Method 2: Using ADB

1. Connect your Android device to your computer via USB
2. Enable USB debugging on your device
3. Run the following command:
   ```
   adb install build/app/outputs/flutter-apk/app-debug.apk
   ```

## Troubleshooting

- If you encounter any errors during the build process, make sure Flutter is correctly installed and configured
- Run `flutter doctor` to diagnose common issues
- Ensure your Android device has developer options and USB debugging enabled

## Key Features of the App

1. Random private key generation for multiple cryptocurrencies
2. Balance checking across BTC, ETH, DOGE, LTC, DASH, and SOL blockchains
3. Brain wallet functionality with dictionary attack options
4. Vanity address targeting for specific address patterns
5. Secure storage of found wallets with encryption
6. Export functionality for wallet data
7. User-friendly interface with real-time scanning statistics
8. Advanced settings for customizing scan behavior
9. Multi-threaded scanning for improved performance

If you have any issues with the build process, please refer to the official Flutter documentation or contact support.