#!/bin/bash

# Script to build the Crypto Wallet Discovery APK

echo "=== Crypto Wallet Discovery App Build Script ==="
echo "This script will help you build the Android APK for the app"
echo

# Check if Flutter is installed
if ! command -v flutter &> /dev/null; then
    echo "Error: Flutter is not installed or not in your PATH"
    echo "Please install Flutter following the instructions at:"
    echo "https://flutter.dev/docs/get-started/install"
    exit 1
fi

# Check Flutter status
echo "Checking Flutter installation..."
flutter doctor

# Get dependencies
echo
echo "Getting Flutter dependencies..."
flutter pub get

# Build the APK
echo
echo "Building the APK..."
flutter build apk --release

# Check if build was successful
if [ $? -eq 0 ]; then
    APK_PATH="$(pwd)/build/app/outputs/flutter-apk/app-release.apk"
    echo
    echo "=== Build Successful! ==="
    echo "APK created at: $APK_PATH"
    echo
    echo "Install on connected device using:"
    echo "adb install -r $APK_PATH"
    echo
    echo "Or transfer the APK file to your Android device manually."
else
    echo
    echo "=== Build Failed ==="
    echo "Please check the error messages above and fix any issues."
fi