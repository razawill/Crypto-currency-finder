# Step-by-Step Guide to Convert the Flutter Project to APK

This guide provides detailed instructions for converting our Crypto Wallet Discovery Flutter project to an Android APK file that you can install on your device.

## Prerequisites

1. **Install Flutter SDK**
   - Download from: https://flutter.dev/docs/get-started/install
   - Follow the platform-specific installation instructions
   - Add Flutter to your PATH
   - Run `flutter doctor` to verify the installation

2. **Install Android Studio**
   - Download from: https://developer.android.com/studio
   - Install with default options
   - Launch Android Studio after installation

3. **Install Android SDK**
   - In Android Studio, go to Tools > SDK Manager
   - In the SDK Platforms tab, select Android 10.0 (API Level 29) or higher
   - In the SDK Tools tab, select:
     - Android SDK Build-Tools
     - Android SDK Command-line Tools
     - Android SDK Platform-Tools
     - Android Emulator
   - Click Apply to install

4. **Configure Flutter with Android Studio**
   - In Android Studio, go to Plugins
   - Search for "Flutter" and install the plugin
   - Restart Android Studio

## Steps to Build the APK

### 1. Clone or Download the Project

If you have git installed:
```
git clone <repository-url>
cd crypto-wallet-discovery
```

Otherwise, download the project as a ZIP and extract it.

### 2. Open the Project in Android Studio

- Launch Android Studio
- Select "Open an existing project"
- Navigate to the project folder and open it

### 3. Verify Flutter Dependencies

In the terminal (or Android Studio's terminal), run:
```
flutter pub get
```

This will download and install all the required Flutter packages.

### 4. Build Debug APK (For Testing)

For quick testing, build a debug APK:
```
flutter build apk --debug
```

The APK will be generated at:
```
build/app/outputs/flutter-apk/app-debug.apk
```

### 5. Build Release APK (For Distribution)

For a smaller, optimized APK suitable for distribution:
```
flutter build apk --release
```

The APK will be generated at:
```
build/app/outputs/flutter-apk/app-release.apk
```

### 6. Build App Bundle (For Google Play Store)

If you plan to publish to the Google Play Store:
```
flutter build appbundle
```

The AAB will be generated at:
```
build/app/outputs/bundle/release/app-release.aab
```

## Installing the APK on Your Device

### Method 1: Direct Transfer

1. Connect your Android device to your computer via USB
2. Enable file transfer on your Android device
3. Copy the APK file to your device
4. On your device, navigate to the APK file location using a file manager
5. Tap the APK file to install
   - You may need to enable "Install from unknown sources" in your device settings:
     - Go to Settings > Security > Unknown sources (or Settings > Apps > Special access > Install unknown apps)

### Method 2: Using ADB (Android Debug Bridge)

1. Connect your Android device to your computer via USB
2. Enable USB debugging on your device (Settings > Developer options > USB debugging)
3. Run the following command:
   ```
   adb install -r build/app/outputs/flutter-apk/app-debug.apk
   ```

## Troubleshooting

- **Flutter doctor shows errors**
  - Follow the recommendations to fix missing dependencies
  
- **Compilation errors**
  - Make sure all dependencies are up-to-date with `flutter pub get`
  - Check Android SDK version compatibility
  
- **Device not detected for installation**
  - Ensure USB debugging is enabled
  - Try a different USB cable or port
  - Install USB drivers for your device

- **APK installation fails**
  - Check if you have enough storage space on the device
  - Make sure "Install from unknown sources" is enabled
  - Uninstall any previous version of the app

## Crypto Wallet Discovery App Features

- Multi-cryptocurrency support (BTC, ETH, DOGE, LTC, DASH, SOL)
- Random private key generation
- Brain wallet functionality with dictionary attack options
- Vanity address targeting for specific patterns
- Balance checking through multiple API services
- Real-time scanning statistics and detailed logs
- Advanced customization options for optimal discovery
- Multi-threaded scanning for improved performance
- Secure wallet storage with encryption

For any questions or issues, please refer to the official Flutter documentation or contact support.